<?php
// Gunakan include_once agar aman
include_once 'koneksi.php';
include_once 'header.php';

// Validasi role Siswa
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
    echo "<script>Swal.fire('Akses Ditolak','Anda harus login sebagai Siswa.','error').then(() => window.location = 'dashboard.php');</script>";
    exit;
}

$id_siswa = $_SESSION['id_siswa'];
$nama_siswa = $_SESSION['nama_siswa'];

// Ambil info tahun ajaran dan semester aktif
$q_ta = mysqli_query($koneksi, "SELECT tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
$tahun_ajaran_aktif = mysqli_fetch_assoc($q_ta)['tahun_ajaran'] ?? '-';
$q_smt = mysqli_query($koneksi, "SELECT nilai_pengaturan FROM pengaturan WHERE nama_pengaturan = 'semester_aktif' LIMIT 1");
$semester_aktif = mysqli_fetch_assoc($q_smt)['nilai_pengaturan'] ?? 1;
$semester_text = ($semester_aktif == 1) ? 'Ganjil' : 'Genap';

// Query untuk mengambil semua nilai sumatif siswa
$query_nilai = mysqli_prepare($koneksi, "
    SELECT 
        mp.nama_mapel,
        mp.kode_mapel,
        p.nama_penilaian,
        p.jenis_penilaian,
        p.subjenis_penilaian,
        p.tanggal_penilaian,
        pdn.nilai
    FROM penilaian_detail_nilai pdn
    JOIN penilaian p ON pdn.id_penilaian = p.id_penilaian
    JOIN mata_pelajaran mp ON p.id_mapel = mp.id_mapel
    WHERE pdn.id_siswa = ? AND p.semester = ?
    ORDER BY mp.urutan ASC, p.tanggal_penilaian DESC
");
mysqli_stmt_bind_param($query_nilai, "is", $id_siswa, $semester_aktif);
mysqli_stmt_execute($query_nilai);
$result_nilai = mysqli_stmt_get_result($query_nilai);

// Mengelompokkan nilai berdasarkan mata pelajaran
$nilai_per_mapel = [];
while ($row = mysqli_fetch_assoc($result_nilai)) {
    $nilai_per_mapel[$row['nama_mapel']][] = $row;
}

// Warna-warni acak untuk ikon mapel
$colors = ['#4facfe', '#00f2fe', '#43e97b', '#38f9d7', '#fa709a', '#fee140', '#667eea', '#764ba2'];
?>

<!-- Style Modern Senada dengan Dashboard -->
<style>
    :root {
        --bg-body: #f8f9fa;
        --card-radius: 16px;
    }
    body {
        background-color: var(--bg-body);
        font-family: 'Poppins', sans-serif;
    }
    
    /* Header Kecil tapi Menarik */
    .page-hero {
        background: linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%);
        padding: 2rem 1.5rem;
        border-radius: 0 0 25px 25px;
        margin-bottom: 2rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        position: relative;
        overflow: hidden;
    }
    .page-hero h2 { font-weight: 800; color: #344767; margin-bottom: 0.5rem; }
    .page-hero p { color: #64748b; font-weight: 500; }
    .page-hero .btn-back {
        background: white; color: #344767;
        border: none; padding: 8px 20px; border-radius: 30px;
        font-weight: 600; font-size: 0.9rem;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: all 0.3s;
        text-decoration: none;
        display: inline-flex; align-items: center;
    }
    .page-hero .btn-back:hover { transform: translateY(-2px); box-shadow: 0 5px 10px rgba(0,0,0,0.15); }

    /* Card Mata Pelajaran (Accordion Style) */
    .accordion-item {
        border: none;
        margin-bottom: 1rem;
        background: transparent;
    }
    .accordion-button {
        background: white;
        border-radius: 16px !important;
        padding: 1.25rem;
        box-shadow: 0 2px 5px rgba(0,0,0,0.03);
        font-weight: 600;
        color: #344767;
        border: 1px solid #f0f2f5;
    }
    .accordion-button:not(.collapsed) {
        background: white;
        color: #344767;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        border-bottom-left-radius: 0 !important;
        border-bottom-right-radius: 0 !important;
    }
    .accordion-button:focus { box-shadow: none; border-color: #f0f2f5; }
    .accordion-button::after {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23344767'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
    }

    .accordion-collapse {
        background: white;
        border-bottom-left-radius: 16px;
        border-bottom-right-radius: 16px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        margin-top: -5px; /* Nempel ke header */
        border: 1px solid #f0f2f5;
        border-top: none;
    }
    
    .mapel-icon {
        width: 40px; height: 40px;
        border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        color: white; font-weight: bold;
        margin-right: 1rem;
        font-size: 1.1rem;
    }

    /* List Nilai Item */
    .nilai-list-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem 1.25rem;
        border-bottom: 1px dashed #e2e8f0;
        transition: background 0.2s;
    }
    .nilai-list-item:last-child { border-bottom: none; }
    .nilai-list-item:hover { background-color: #f8fafc; }
    
    .nilai-title { font-weight: 600; color: #344767; margin-bottom: 2px; }
    .nilai-meta { font-size: 0.8rem; color: #8392ab; }
    .nilai-badge {
        width: 45px; height: 45px;
        border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-weight: 800; font-size: 1.1rem;
        color: #344767;
        background: #f0f2f5;
    }
    .nilai-badge.high { background: #d1fae5; color: #059669; } /* Hijau untuk nilai bagus */
    .nilai-badge.mid { background: #fef3c7; color: #d97706; }  /* Kuning untuk nilai sedang */
    .nilai-badge.low { background: #fee2e2; color: #dc2626; }  /* Merah untuk nilai rendah */

    .empty-state {
        text-align: center;
        padding: 4rem 1rem;
    }
    .empty-img { width: 120px; opacity: 0.6; margin-bottom: 1rem; }
</style>

<div class="page-hero">
    <div class="container-fluid d-flex flex-column flex-md-row justify-content-between align-items-md-center">
        <div class="mb-3 mb-md-0">
            <h2>Rincian Nilai Akademik</h2>
            <p class="mb-0">
                Tahun Ajaran <?php echo $tahun_ajaran_aktif; ?> &bull; Semester <?php echo $semester_text; ?>
            </p>
        </div>
        <a href="dashboard.php" class="btn-back shadow-sm">
            <i class="bi bi-arrow-left me-2"></i> Kembali
        </a>
    </div>
</div>

<div class="container-fluid px-4 pb-5">
    
    <?php if (empty($nilai_per_mapel)): ?>
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body empty-state">
                <img src="assets/img/empty-box.svg" alt="Kosong" class="empty-img">
                <h5 class="fw-bold text-secondary">Belum Ada Data Nilai</h5>
                <p class="text-muted">Bapak/Ibu Guru belum menginput nilai sumatif untuk semester ini.</p>
                <a href="dashboard_siswa.php" class="btn btn-outline-primary rounded-pill px-4 mt-2">Kembali ke Dashboard</a>
            </div>
        </div>
    <?php else: ?>
        
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="accordion" id="nilaiAccordion">
                    <?php 
                    $i = 0; 
                    foreach ($nilai_per_mapel as $nama_mapel => $penilaian_list): 
                        $i++;
                        // Warna acak konsisten per mapel (berdasarkan panjang string nama mapel)
                        $color_index = strlen($nama_mapel) % count($colors);
                        $bg_color = $colors[$color_index];
                        // Inisial Mapel
                        $inisial = strtoupper(substr($nama_mapel, 0, 1));
                        
                        // Hitung rata-rata sementara untuk badge di header (Opsional)
                        $total = 0;
                        foreach($penilaian_list as $p) $total += $p['nilai'];
                        $avg = count($penilaian_list) > 0 ? round($total / count($penilaian_list)) : 0;
                    ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button <?php if($i > 1) echo 'collapsed'; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo $i; ?>">
                                    <div class="d-flex align-items-center w-100 pe-3">
                                        <div class="mapel-icon shadow-sm" style="background: <?php echo $bg_color; ?>;">
                                            <?php echo $inisial; ?>
                                        </div>
                                        <div class="flex-grow-1">
                                            <div class="fw-bold text-dark"><?php echo htmlspecialchars($nama_mapel); ?></div>
                                            <div class="small text-muted"><?php echo count($penilaian_list); ?> Penilaian</div>
                                        </div>
                                        <div class="d-none d-sm-block text-end">
                                            <span class="badge bg-light text-dark border">Rerata: <?php echo $avg; ?></span>
                                        </div>
                                    </div>
                                </button>
                            </h2>
                            <div id="collapse-<?php echo $i; ?>" class="accordion-collapse collapse <?php if($i == 1) echo 'show'; ?>" data-bs-parent="#nilaiAccordion">
                                <div class="accordion-body p-0">
                                    <?php foreach ($penilaian_list as $penilaian): 
                                        $nilai = $penilaian['nilai'];
                                        $badge_class = 'mid';
                                        if($nilai >= 85) $badge_class = 'high';
                                        elseif($nilai < 70) $badge_class = 'low';
                                        
                                        $subjenis = !empty($penilaian['subjenis_penilaian']) ? $penilaian['subjenis_penilaian'] : 'Sumatif Lingkup Materi';
                                    ?>
                                        <div class="nilai-list-item">
                                            <div>
                                                <div class="nilai-title"><?php echo htmlspecialchars($penilaian['nama_penilaian']); ?></div>
                                                <div class="nilai-meta">
                                                    <i class="bi bi-calendar2-event me-1"></i> <?php echo date('d M Y', strtotime($penilaian['tanggal_penilaian'])); ?>
                                                    &bull; <span class="text-primary"><?php echo htmlspecialchars($subjenis); ?></span>
                                                </div>
                                            </div>
                                            <div class="nilai-badge <?php echo $badge_class; ?>">
                                                <?php echo $nilai; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>