<?php
// =======================================================================
// TEMPLATE KONTEN RAPOR (INCLUDED FILE)
// Dipanggil oleh: rapor_cetak_massal.php di dalam loop
// Variabel tersedia: $koneksi, $id_siswa, $id_tahun_ajaran_pdf, $semester_aktif_pdf
// =======================================================================

// 1. AMBIL DATA SISWA SPESIFIK
$q_siswa_pdf = "SELECT s.nama_lengkap, s.nis, s.nisn, s.agama, s.id_kelas, k.nama_kelas, k.fase, g.nama_guru as nama_walikelas, g.nip as nip_walikelas
                FROM siswa s 
                LEFT JOIN kelas k ON s.id_kelas = k.id_kelas 
                LEFT JOIN guru g ON k.id_wali_kelas = g.id_guru 
                WHERE s.id_siswa = ?";
$stmt_siswa_pdf = mysqli_prepare($koneksi, $q_siswa_pdf);
mysqli_stmt_bind_param($stmt_siswa_pdf, "i", $id_siswa);
mysqli_stmt_execute($stmt_siswa_pdf);
$result_siswa = mysqli_stmt_get_result($stmt_siswa_pdf);

if (mysqli_num_rows($result_siswa) == 0) return; // Skip jika data rusak
$siswa_pdf = mysqli_fetch_assoc($result_siswa);
$id_kelas_siswa = $siswa_pdf['id_kelas'];

// 2. AMBIL DATA RAPOR (SAKIT, IZIN, CATATAN)
$q_rapor = mysqli_prepare($koneksi, "SELECT * FROM rapor WHERE id_siswa = ? AND semester = ? AND id_tahun_ajaran = ? LIMIT 1");
mysqli_stmt_bind_param($q_rapor, "iii", $id_siswa, $semester_aktif_pdf, $id_tahun_ajaran_pdf);
mysqli_stmt_execute($q_rapor);
$rapor_pdf = mysqli_fetch_assoc(mysqli_stmt_get_result($q_rapor));
$id_rapor = $rapor_pdf['id_rapor'] ?? 0;
$show_nilai_column_pdf = true;

// 3. LOGIKA MAPEL (FILTER AGAMA & URUTAN)
$mapel_agama_map_pdf = ['Islam'=>2, 'Kristen'=>13, 'Hindu'=>14, 'Budha'=>15, 'Katolik'=>16, 'Khonghucu'=>0];
$agama_siswa = $siswa_pdf['agama'] ?? '';
$id_mapel_agama = $mapel_agama_map_pdf[$agama_siswa] ?? null;
$semua_agama_ids = implode(',', array_filter(array_values($mapel_agama_map_pdf))) ?: '0';

$query_mapel_str = "SELECT mp.id_mapel, mp.nama_mapel, mp.urutan 
                    FROM mata_pelajaran mp 
                    JOIN guru_mengajar gm ON mp.id_mapel = gm.id_mapel
                    WHERE gm.id_kelas = '$id_kelas_siswa' AND gm.id_tahun_ajaran = '$id_tahun_ajaran_pdf'";

if ($id_mapel_agama) {
    $query_mapel_str .= " AND (mp.id_mapel NOT IN ($semua_agama_ids) OR mp.id_mapel = $id_mapel_agama)";
} else {
    $query_mapel_str .= " AND mp.id_mapel NOT IN ($semua_agama_ids)";
}
$query_mapel_str .= " GROUP BY mp.id_mapel ORDER BY mp.urutan ASC, mp.nama_mapel ASC";
$q_mapel = mysqli_query($koneksi, $query_mapel_str);

// 4. PREPARE NILAI (DB & LIVE)
$nilai_tersimpan = [];
if ($id_rapor > 0) {
    $q_detail = mysqli_query($koneksi, "SELECT id_mapel, nilai_akhir, nilai_katrol, capaian_kompetensi FROM rapor_detail_akademik WHERE id_rapor = $id_rapor");
    while ($d = mysqli_fetch_assoc($q_detail)) {
        $val = ($d['nilai_katrol'] > 0) ? $d['nilai_katrol'] : $d['nilai_akhir'];
        $nilai_tersimpan[$d['id_mapel']] = ['nilai' => $val, 'deskripsi' => $d['capaian_kompetensi']];
    }
}

$daftar_mapel_rapor = [];
while ($mp = mysqli_fetch_assoc($q_mapel)) {
    $id_m = $mp['id_mapel'];
    
    // HITUNG LIVE (Memanggil fungsi global dari rapor_cetak_massal.php)
    $deskripsi_live = hitungDeskripsiOtomatis($koneksi, $id_siswa, $id_kelas_siswa, $id_m, $kkm, $semester_aktif_pdf);
    
    // Prioritas: Nilai DB > Nilai Live (jika belum disimpan)
    $nilai_final = $nilai_tersimpan[$id_m]['nilai'] ?? '-';
    $deskripsi_final = (!empty($nilai_tersimpan[$id_m]['deskripsi'])) ? $nilai_tersimpan[$id_m]['deskripsi'] : $deskripsi_live;
    
    $daftar_mapel_rapor[] = [
        'nama_mapel' => $mp['nama_mapel'],
        'nilai_akhir' => $nilai_final,
        'capaian_kompetensi' => $deskripsi_final
    ];
}

// 5. MERGE SENI & PRAKARYA
$seni_data = null; $prakarya_data = null;
$seni_idx = -1; $prakarya_idx = -1;

foreach ($daftar_mapel_rapor as $idx => $m) {
    if (in_array($m['nama_mapel'], ['Seni Musik', 'Seni Rupa', 'Seni Tari', 'Seni Teater'])) { $seni_data = $m; $seni_idx = $idx; }
    if ($m['nama_mapel'] == 'Prakarya') { $prakarya_data = $m; $prakarya_idx = $idx; }
}

if ($seni_data && $prakarya_data) {
    // Jika siswa punya keduanya
    $n1 = (int)$seni_data['nilai_akhir'];
    $n2 = (int)$prakarya_data['nilai_akhir'];
    $avg = ($n1 > 0 && $n2 > 0) ? round(($n1 + $n2) / 2) : max($n1, $n2);
    
    $merged_desc = trim($seni_data['capaian_kompetensi']) . "\n" . trim($prakarya_data['capaian_kompetensi']);
    
    $daftar_mapel_rapor[$seni_idx] = [
        'nama_mapel' => 'Seni Budaya dan Prakarya',
        'nilai_akhir' => ($avg > 0 ? $avg : '-'),
        'capaian_kompetensi' => trim($merged_desc)
    ];
    unset($daftar_mapel_rapor[$prakarya_idx]); // Hapus Prakarya
    $daftar_mapel_rapor = array_values($daftar_mapel_rapor); // Re-index
} elseif ($seni_data) {
    $daftar_mapel_rapor[$seni_idx]['nama_mapel'] = 'Seni Budaya dan Prakarya';
} elseif ($prakarya_data) {
    $daftar_mapel_rapor[$prakarya_idx]['nama_mapel'] = 'Seni Budaya dan Prakarya';
}

// 6. EKSKUL (QUERY LENGKAP)
$q_ekskul = mysqli_prepare($koneksi, "
    SELECT e.nama_ekskul, kh.jumlah_hadir, kh.total_pertemuan,
    (SELECT GROUP_CONCAT(CONCAT(et.deskripsi_tujuan, ': ', pn.nilai) SEPARATOR '; ') 
     FROM ekskul_penilaian pn
     JOIN ekskul_tujuan et ON pn.id_tujuan_ekskul = et.id_tujuan_ekskul
     WHERE pn.id_peserta_ekskul = ep.id_peserta_ekskul AND et.semester = ?) as deskripsi_raw
    FROM ekskul_peserta ep
    JOIN ekstrakurikuler e ON ep.id_ekskul = e.id_ekskul
    LEFT JOIN ekskul_kehadiran kh ON ep.id_peserta_ekskul = kh.id_peserta_ekskul AND kh.semester = ?
    WHERE ep.id_siswa = ? ORDER BY e.nama_ekskul ASC
");
mysqli_stmt_bind_param($q_ekskul, "iii", $semester_aktif_pdf, $semester_aktif_pdf, $id_siswa);
mysqli_stmt_execute($q_ekskul);
$res_ekskul = mysqli_stmt_get_result($q_ekskul);
?>

<!-- HTML CONTENT START -->
<main>
    <!-- Tabel Identitas -->
    <table class="info-table">
        <tr>
            <td width="20%">Nama Murid</td><td width="1%">:</td><td width="34%"><b><?php echo htmlspecialchars($siswa_pdf['nama_lengkap']); ?></b></td>
            <td width="20%">Kelas</td><td width="1%">:</td><td width="24%"><?php echo htmlspecialchars($siswa_pdf['nama_kelas']); ?></td>
        </tr>
        <tr>
            <td>NISN / NIS</td><td>:</td><td><?php echo htmlspecialchars(($siswa_pdf['nisn'] ?? '-') . ' / ' . ($siswa_pdf['nis'] ?? '-')); ?></td>
            <td>Fase</td><td>:</td><td><?php echo htmlspecialchars($siswa_pdf['fase']); ?></td>
        </tr>
        <tr>
            <td>Sekolah</td><td>:</td><td><?php echo htmlspecialchars($sekolah_pdf['nama_sekolah']); ?></td>
            <td>Semester</td><td>:</td><td><?php echo $semester_text_pdf; ?></td>
        </tr>
        <tr>
            <td>Alamat Sekolah</td><td>:</td><td><?php echo htmlspecialchars($sekolah_pdf['jalan']); ?>, <?php echo htmlspecialchars($sekolah_pdf['desa_kelurahan']); ?></td>
            <td>Tahun Ajaran</td><td>:</td><td><?php echo htmlspecialchars($tahun_ajaran_pdf); ?></td>
        </tr>
    </table>
    
    <div style="border-bottom: 1px solid #000; margin-bottom: 5px;"></div>

    <!-- A. NILAI AKADEMIK -->
    <div class="section-title">A. NILAI AKADEMIK</div>
    <table class="content-table">
        <thead>
            <tr>
                <th width="5%">No.</th>
                <th width="25%">Mata Pelajaran</th>
                <th width="8%">Nilai Akhir</th>
                <th>Capaian Kompetensi</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            foreach ($daftar_mapel_rapor as $mapel): 
            ?>
            <tr>
                <td class="text-center"><?php echo $no++; ?></td>
                <td><?php echo htmlspecialchars($mapel['nama_mapel']); ?></td>
                <td class="nilai-cetak"><?php echo $mapel['nilai_akhir']; ?></td>
                <td class="capaian"><?php echo nl2br(htmlspecialchars($mapel['capaian_kompetensi'])); ?></td>
            </tr>
            <?php endforeach; ?>
            
            <?php if (empty($daftar_mapel_rapor)): ?>
            <tr><td colspan="4" class="text-center">Data nilai belum tersedia.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- B. KOKURIKULER -->
    <table class="content-table" style="margin-top: 20px;">
        <thead>
            <tr><th style="text-align:left; padding-left:10px;">B. KOKURIKULER</th></tr>
        </thead>
        <tbody>
            <tr>
                <td class="capaian"><?php echo !empty($rapor_pdf['deskripsi_kokurikuler']) ? nl2br(htmlspecialchars($rapor_pdf['deskripsi_kokurikuler'])) : '-'; ?></td>
            </tr>
        </tbody>
    </table>

    <!-- C. EKSTRAKURIKULER -->
    <div class="section-title">C. EKSTRAKURIKULER</div>
    <table class="content-table">
        <thead>
            <tr>
                <th width="5%">No.</th>
                <th width="25%">Ekstrakurikuler</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no_eks = 1;
            $found_eks = false;
            while ($eks = mysqli_fetch_assoc($res_ekskul)): 
                $found_eks = true;
                
                // Parsing Deskripsi Ekskul (Simple & Clean)
                $desc_text = "Aktif mengikuti kegiatan.";
                if (!empty($eks['deskripsi_raw'])) {
                    // Ubah format "Disiplin: SB" menjadi narasi jika perlu, atau tampilkan langsung
                    // Di sini kita rapikan separatornya saja agar hemat tempat
                    $desc_text = str_replace(['; '], [', '], $eks['deskripsi_raw']);
                    
                    // Optional: Ubah kode SB/B/C jadi kata (opsional, sesuaikan kebutuhan)
                    $desc_text = "Capaian: " . $desc_text . ".";
                }
                
                // Tambahan Kehadiran
                if ($eks['total_pertemuan'] > 0) {
                    $persen = round(($eks['jumlah_hadir'] / $eks['total_pertemuan']) * 100);
                    $desc_text .= " Kehadiran: {$eks['jumlah_hadir']}/{$eks['total_pertemuan']} ({$persen}%).";
                } elseif ($eks['jumlah_hadir'] !== null) {
                    $desc_text .= " Kehadiran: {$eks['jumlah_hadir']} pertemuan.";
                }
            ?>
            <tr>
                <td class="text-center"><?php echo $no_eks++; ?></td>
                <td><b><?php echo htmlspecialchars($eks['nama_ekskul']); ?></b></td>
                <td class="capaian"><?php echo $desc_text; ?></td>
            </tr>
            <?php endwhile; ?>
            
            <?php if (!$found_eks): ?>
            <tr><td colspan="3" class="text-center">Tidak mengikuti kegiatan ekstrakurikuler.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- D. KETIDAKHADIRAN & E. CATATAN -->
    <div style="width: 100%; margin-top: 15px; page-break-inside: avoid;">
        <div style="width: 40%; float: left;">
            <div class="section-title" style="margin-top:0;">D. KETIDAKHADIRAN</div>
            <table class="content-table">
                <tr><td width="70%">Sakit</td><td>: <?php echo $rapor_pdf['sakit'] ?? 0; ?> hari</td></tr>
                <tr><td>Izin</td><td>: <?php echo $rapor_pdf['izin'] ?? 0; ?> hari</td></tr>
                <tr><td>Tanpa Keterangan</td><td>: <?php echo $rapor_pdf['tanpa_keterangan'] ?? 0; ?> hari</td></tr>
            </table>
        </div>
        <div style="width: 55%; float: right;">
            <div class="section-title" style="margin-top:0;">E. CATATAN WALI KELAS</div>
            <table class="content-table" style="height: 80px;">
                <tr><td class="capaian"><?php echo !empty($rapor_pdf['catatan_wali_kelas']) ? nl2br(htmlspecialchars($rapor_pdf['catatan_wali_kelas'])) : '-'; ?></td></tr>
            </table>
        </div>
        <div style="clear:both;"></div>
    </div>

    <!-- TANDA TANGAN -->
    <div class="section-title">Tanggapan Orang Tua/Wali Murid</div>
    <table class="content-table"><tr><td style="height: 60px;"></td></tr></table>

    <table class="signature-table">
        <tr>
            <td>
                Orang Tua/Wali Murid
                <div class="signature-space"></div>
                ( ................................. )
            </td>
            <td>
                Mengetahui,<br>Kepala Sekolah
                <div class="signature-space"></div>
                <strong><u><?php echo htmlspecialchars($sekolah_pdf['nama_kepsek']); ?></u></strong><br>
                <span style="font-size: 9pt;"><?php echo htmlspecialchars($sekolah_pdf['jabatan_kepsek']); ?></span><br>
                NIP. <?php echo htmlspecialchars($sekolah_pdf['nip_kepsek']); ?>
            </td>
            <td>
                <?php echo htmlspecialchars($sekolah_pdf['kabupaten_kota']); ?>, <?php echo $tanggal_rapor_pdf; ?><br>
                Wali Kelas
                <div class="signature-space"></div>
                <strong><u><?php echo htmlspecialchars($siswa_pdf['nama_walikelas'] ?? '........................'); ?></u></strong><br>
                NIP. <?php echo htmlspecialchars($siswa_pdf['nip_walikelas'] ?? '........................'); ?>
            </td>
        </tr>
    </table>
</main>
<!-- HTML CONTENT END -->