<?php
// =======================================================================
// TEMPLATE IDENTITAS SISWA (INCLUDED FILE)
// Dipanggil oleh: rapor_cetak_massal.php
// =======================================================================

// 1. AMBIL DATA SISWA LENGKAP
$q_identitas = mysqli_prepare($koneksi, "SELECT * FROM siswa WHERE id_siswa = ?");
mysqli_stmt_bind_param($q_identitas, "i", $id_siswa);
mysqli_stmt_execute($q_identitas);
$d_sis = mysqli_fetch_assoc(mysqli_stmt_get_result($q_identitas));

if (!$d_sis) return; // Skip jika data kosong

// 2. AMBIL DATA SEKOLAH (Untuk TTD Kepala Sekolah)
$kecamatan_sekolah = $sekolah_pdf['kecamatan'] ?? ''; 
$kabupaten_sekolah = $sekolah_pdf['kabupaten_kota'] ?? '';

// 3. FOTO SISWA
$foto_html = ''; 
if (!empty($d_sis['foto_siswa'])) {
    if (function_exists('get_img_base64_local')) {
        $foto_base64 = get_img_base64_local('foto_siswa/' . $d_sis['foto_siswa']);
        if ($foto_base64) {
            $foto_html = '<img src="' . $foto_base64 . '" style="width: 100%; height: 100%; object-fit: cover;">';
        }
    }
}
// Placeholder jika foto kosong
if (empty($foto_html)) {
    $foto_html = '<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; font-size: 8pt; color: #ccc; background-color: #f9f9f9;">FOTO<br>3 x 4</div>';
}
?>

<!-- HTML CONTENT START -->
<!-- Wrapper Utama untuk Margin Kiri/Kanan (Agar aman dijilid) -->
<div style="padding: 0 30px;">

    <!-- Judul Rapor Identitas (Dinaikkan sedikit dengan margin-top negatif jika perlu, atau 0) -->
    <div style="text-align: center; font-weight: bold; font-size: 16pt; margin-top: -20px; margin-bottom: 10px; text-transform: uppercase; border-bottom: 3px double #333; padding-bottom: 10px; display: inline-block; width: 100%;">
        IDENTITAS PESERTA DIDIK
    </div>

    <div>
        <!-- TABEL BIODATA -->
        <!-- Style: border-bottom tipis untuk setiap baris agar mudah dibaca -->
        <style>
            .biodata-table { width: 100%; border-collapse: collapse; font-family: 'Times New Roman', serif; }
            .biodata-table td { padding: 6px 5px; vertical-align: top; border-bottom: 1px solid #e0e0e0; }
            .biodata-table tr:last-child td { border-bottom: none; } /* Hapus garis di baris terakhir */
            .label-text { color: #444; }
            .value-text { color: #000; font-weight: 500; }
            .sub-header { font-weight: bold; background-color: #f4f4f4; padding-left: 10px; }
        </style>

        <table class="biodata-table">
            <tr>
                <td class="num" style="width: 5%;">1.</td>
                <td class="label-text" style="width: 30%;">Nama Lengkap Peserta Didik</td>
                <td class="separator" style="width: 2%;">:</td>
                <td class="value-text" style="width: 63%; font-size: 12pt;"><b><?php echo strtoupper(htmlspecialchars($d_sis['nama_lengkap'])); ?></b></td>
            </tr>
            <tr>
                <td class="num">2.</td>
                <td class="label-text">NIS / NISN</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars(($d_sis['nis']??'-') . ' / ' . ($d_sis['nisn']??'-')); ?></td>
            </tr>
            <tr>
                <td class="num">3.</td>
                <td class="label-text">Tempat, Tanggal Lahir</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['tempat_lahir']) . ', ' . tanggal_indo($d_sis['tanggal_lahir']); ?></td>
            </tr>
            <tr>
                <td class="num">4.</td>
                <td class="label-text">Jenis Kelamin</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo ($d_sis['jenis_kelamin'] == 'L') ? 'Laki-laki' : 'Perempuan'; ?></td>
            </tr>
            <tr>
                <td class="num">5.</td>
                <td class="label-text">Agama</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['agama']); ?></td>
            </tr>
            <tr>
                <td class="num">6.</td>
                <td class="label-text">Status dalam Keluarga</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['status_dalam_keluarga']); ?></td>
            </tr>
            <tr>
                <td class="num">7.</td>
                <td class="label-text">Anak ke</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['anak_ke']); ?></td>
            </tr>
            <tr>
                <td class="num">8.</td>
                <td class="label-text">Alamat Peserta Didik</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['alamat']); ?></td>
            </tr>
            <tr>
                <td class="num">9.</td>
                <td class="label-text">Nomor Telepon/HP</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['telepon_siswa']); ?></td>
            </tr>
            <tr>
                <td class="num">10.</td>
                <td class="label-text">Sekolah Asal</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['sekolah_asal']); ?></td>
            </tr>
            
            <!-- BAGIAN DITERIMA DI SEKOLAH -->
            <tr style="background-color: #fafafa;">
                <td class="num">11.</td>
                <td colspan="3" style="font-weight: bold; color: #333;">Diterima di sekolah ini</td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">Di kelas</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa_pdf['nama_kelas'] ?? '-'); ?></td> 
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">Pada tanggal</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo !empty($d_sis['diterima_tanggal']) ? tanggal_indo($d_sis['diterima_tanggal']) : '-'; ?></td>
            </tr>

            <!-- ORANG TUA -->
            <tr style="background-color: #fafafa;">
                <td class="num">12.</td>
                <td colspan="3" style="font-weight: bold; color: #333;">Nama Orang Tua</td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">a. Ayah</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['nama_ayah']); ?></td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">b. Ibu</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['nama_ibu']); ?></td>
            </tr>
            <tr>
                <td class="num">13.</td>
                <td class="label-text">Alamat Orang Tua</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['alamat']); ?></td>
            </tr>
            <tr>
                <td class="num">14.</td>
                <td class="label-text">Pekerjaan Orang Tua</td>
                <td class="separator">:</td>
                <td class="value-text"></td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">a. Ayah</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['pekerjaan_ayah']); ?></td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">b. Ibu</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['pekerjaan_ibu']); ?></td>
            </tr>
            
            <!-- WALI -->
            <tr style="background-color: #fafafa;">
                <td class="num">15.</td>
                <td class="label-text">Nama Wali Siswa</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['nama_wali']); ?></td>
            </tr>
            <tr>
                <td class="num">16.</td>
                <td class="label-text">Alamat Wali</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['alamat_wali']); ?></td>
            </tr>
            <tr>
                <td class="num">17.</td>
                <td class="label-text">Pekerjaan Wali</td>
                <td class="separator">:</td>
                <td class="value-text"><?php echo htmlspecialchars($d_sis['pekerjaan_wali']); ?></td>
            </tr>
        </table>
    </div>

    <!-- BAGIAN TANDA TANGAN DAN FOTO -->
    <table class="signature-table" style="margin-top: 35px; width: 100%; page-break-inside: avoid; border: none;">
        <tr>
            <!-- Kolom Spacer Kiri -->
            <td style="width: 35%; border: none;"></td> 
            
            <!-- Kolom FOTO (Posisi rapat dengan tanda tangan di sebelah kirinya) -->
            <td style="width: 20%; vertical-align: bottom; text-align: center; padding-right: 15px; padding-bottom: 5px; border: none;">
                <div style="width: 3cm; height: 4cm; border: 1px solid #333; display: inline-block; background-color: #fff; padding: 2px;">
                    <?php echo $foto_html; ?>
                </div>
            </td>
            
            <!-- Kolom Tanda Tangan -->
            <td style="width: 45%; vertical-align: top; text-align: left; padding-left: 5px; border: none;">
                <div style="text-align: left; font-size: 11pt;">
                    <?php echo htmlspecialchars($kabupaten_sekolah); ?>, <?php echo $tanggal_rapor_pdf; ?><br>
                    Kepala Sekolah,<br>
                    <br><br><br><br><br> <!-- Jarak Tanda Tangan -->
                    <strong><u><?php echo htmlspecialchars($sekolah_pdf['nama_kepsek']); ?></u></strong><br>
                    NIP. <?php echo htmlspecialchars($sekolah_pdf['nip_kepsek']); ?>
                </div>
            </td>
        </tr>
    </table>

</div>
<!-- HTML CONTENT END -->