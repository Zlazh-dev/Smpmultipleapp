<?php
include 'header.php';
include 'koneksi.php';

$id_guru_login = (int)$_SESSION['id_guru']; 
$role_login = $_SESSION['role'];

// 1. Ambil Tahun Ajaran Aktif
$q_ta = mysqli_query($koneksi, "SELECT id_tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
$ta_aktif = mysqli_fetch_assoc($q_ta);
$id_tahun_ajaran_aktif = $ta_aktif['id_tahun_ajaran'] ?? 0;

// 2. Ambil Daftar Kegiatan (Filter sesuai hak akses)
// Admin/Koordinator melihat semua kegiatan yang mereka pegang.
// Anggota Tim melihat kegiatan di mana mereka ditugaskan.
$query_kegiatan = "
    SELECT DISTINCT k.id_kegiatan, k.tema_kegiatan, k.semester, k.id_koordinator
    FROM kokurikuler_kegiatan k
    LEFT JOIN kokurikuler_tim_penilai kt ON k.id_kegiatan = kt.id_kegiatan
    WHERE k.id_tahun_ajaran = ? 
    AND (
        ? = 'admin' 
        OR k.id_koordinator = ? 
        OR kt.id_guru = ?
    )
    ORDER BY k.semester, k.tema_kegiatan
";
$stmt_keg = mysqli_prepare($koneksi, $query_kegiatan);
mysqli_stmt_bind_param($stmt_keg, "issi", $id_tahun_ajaran_aktif, $role_login, $id_guru_login, $id_guru_login);
mysqli_stmt_execute($stmt_keg);
$daftar_kegiatan = mysqli_fetch_all(mysqli_stmt_get_result($stmt_keg), MYSQLI_ASSOC);

// Ambil ID dari URL
$id_kegiatan_pilih = isset($_GET['kegiatan']) ? (int)$_GET['kegiatan'] : 0;
$id_kelas_pilih = isset($_GET['kelas']) ? (int)$_GET['kelas'] : 0;

// 3. Logika Mengambil Daftar Kelas (Jika Kegiatan Sudah Dipilih)
$daftar_kelas = [];
if ($id_kegiatan_pilih > 0) {
    // Cek dulu apakah user adalah koordinator atau admin untuk kegiatan ini
    $cek_koor = mysqli_query($koneksi, "SELECT id_koordinator FROM kokurikuler_kegiatan WHERE id_kegiatan = $id_kegiatan_pilih");
    $data_keg = mysqli_fetch_assoc($cek_koor);
    $is_admin_or_koor = ($role_login == 'admin' || ($data_keg && $data_keg['id_koordinator'] == $id_guru_login));

    if ($is_admin_or_koor) {
        // Jika Admin/Koordinator: Tampilkan SEMUA kelas yang terlibat dalam projek ini
        $q_kelas = "
            SELECT k.id_kelas, k.nama_kelas 
            FROM kokurikuler_kelas_terlibat kkt
            JOIN kelas k ON kkt.id_kelas = k.id_kelas
            WHERE kkt.id_kegiatan = ?
            ORDER BY k.nama_kelas ASC
        ";
        $stmt_kls = mysqli_prepare($koneksi, $q_kelas);
        mysqli_stmt_bind_param($stmt_kls, "i", $id_kegiatan_pilih);
    } else {
        // Jika Anggota Tim: Tampilkan HANYA kelas yang ditugaskan kepadanya
        $q_kelas = "
            SELECT k.id_kelas, k.nama_kelas 
            FROM kokurikuler_tim_penilai ktp
            JOIN kelas k ON ktp.id_kelas = k.id_kelas
            WHERE ktp.id_kegiatan = ? AND ktp.id_guru = ?
            ORDER BY k.nama_kelas ASC
        ";
        $stmt_kls = mysqli_prepare($koneksi, $q_kelas);
        mysqli_stmt_bind_param($stmt_kls, "ii", $id_kegiatan_pilih, $id_guru_login);
    }
    
    mysqli_stmt_execute($stmt_kls);
    $daftar_kelas = mysqli_fetch_all(mysqli_stmt_get_result($stmt_kls), MYSQLI_ASSOC);
}

?>

<!-- Tambahkan Select2 CSS & JS untuk fitur Search -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<style>
    .page-header { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); padding: 2.5rem 2rem; border-radius: 0.75rem; color: white; }
    .page-header h1 { font-weight: 700; }
    
    /* Sticky Table Header & First Column */
    .table-assessment { table-layout: fixed; }
    .table-assessment .horizontal-header { text-align: center; vertical-align: middle; padding: 0.75rem; width: 220px; white-space: normal; font-size: 0.9rem;}
    .table-assessment .sticky-col { position: sticky; left: 0; z-index: 10; background-color: #fff; width: 250px; min-width: 250px; border-right: 2px solid #dee2e6; }
    .table-assessment thead th { position: sticky; top: 0; z-index: 11; background-color: #f8f9fa; box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4); }
    .table-assessment thead th.sticky-col { z-index: 12; } /* Sudut kiri atas harus paling tinggi */

    /* Tombol Nilai */
    .value-buttons { display: flex; justify-content: center; gap: 5px; margin-bottom: 5px; }
    .value-buttons .btn-nilai { border-radius: 50%; width: 35px; height: 35px; font-weight: 700; font-size: 0.8rem; padding: 0; transition: all 0.2s ease; display: flex; align-items: center; justify-content: center; }
    .value-buttons .btn-nilai:not(.active) { opacity: 0.5; background-color: white; }
    .value-buttons .btn-nilai:not(.active):hover { opacity: 1; transform: scale(1.1); }
    
    /* Warna Aktif */
    .btn-nilai.active.btn-sb { background-color: #198754 !important; color: white !important; border-color: #198754; box-shadow: 0 0 8px rgba(25, 135, 84, 0.5); }
    .btn-nilai.active.btn-b { background-color: #0d6efd !important; color: white !important; border-color: #0d6efd; box-shadow: 0 0 8px rgba(13, 110, 253, 0.5); }
    .btn-nilai.active.btn-c { background-color: #ffc107 !important; color: black !important; border-color: #ffc107; box-shadow: 0 0 8px rgba(255, 193, 7, 0.5); }
    .btn-nilai.active.btn-k { background-color: #dc3545 !important; color: white !important; border-color: #dc3545; box-shadow: 0 0 8px rgba(220, 53, 69, 0.5); }

    /* Warna Outline (Default) */
    .btn-sb { color: #198754; border-color: #198754; }
    .btn-b { color: #0d6efd; border-color: #0d6efd; }
    .btn-c { color: #ffc107; border-color: #ffc107; }
    .btn-k { color: #dc3545; border-color: #dc3545; }
    
    /* Sticky Footer for Save Button */
    .sticky-footer { position: sticky; bottom: 0; background: white; padding: 1rem; border-top: 1px solid #ddd; box-shadow: 0 -4px 10px rgba(0,0,0,0.05); z-index: 100; text-align: right; }
</style>

<div class="container-fluid">
    <div class="page-header text-white mb-4 shadow-sm">
        <h1 class="mb-0">Input Asesmen Kokurikuler</h1>
        <p class="lead opacity-75">Pilih kegiatan dan kelas untuk memulai penilaian.</p>
    </div>

    <!-- FILTER AREA -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form action="" method="GET" class="row g-3 align-items-end">
                <!-- Pilih Kegiatan -->
                <div class="col-md-5">
                    <label for="kegiatan" class="form-label fw-bold">1. Pilih Kegiatan Projek</label>
                    <select name="kegiatan" id="kegiatan" class="form-select select2" onchange="this.form.submit()">
                        <option value="">-- Cari / Pilih Kegiatan --</option>
                        <?php foreach($daftar_kegiatan as $kegiatan): ?>
                        <option value="<?php echo $kegiatan['id_kegiatan']; ?>" <?php echo ($id_kegiatan_pilih == $kegiatan['id_kegiatan']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kegiatan['tema_kegiatan']); ?> (Sem <?php echo $kegiatan['semester']; ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Pilih Kelas (Dinamis berdasarkan kegiatan) -->
                <div class="col-md-5">
                    <label for="kelas" class="form-label fw-bold">2. Pilih Kelas Sasaran</label>
                    <select name="kelas" id="kelas" class="form-select select2" <?php echo empty($daftar_kelas) ? 'disabled' : ''; ?>>
                        <option value="">-- Cari / Pilih Kelas --</option>
                        <?php foreach($daftar_kelas as $kls): ?>
                        <option value="<?php echo $kls['id_kelas']; ?>" <?php echo ($id_kelas_pilih == $kls['id_kelas']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kls['nama_kelas']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if($id_kegiatan_pilih > 0 && empty($daftar_kelas)): ?>
                        <div class="form-text text-danger">Anda tidak memiliki akses ke kelas mana pun di kegiatan ini.</div>
                    <?php endif; ?>
                </div>

                <!-- Tombol Tampilkan -->
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100 h-100" <?php echo ($id_kegiatan_pilih == 0) ? 'disabled' : ''; ?>>
                        <i class="bi bi-search me-2"></i>Tampilkan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- AREA PENILAIAN -->
    <?php if ($id_kegiatan_pilih > 0 && $id_kelas_pilih > 0): 
        // 1. Ambil Dimensi (Kolom)
        $q_dimensi = mysqli_prepare($koneksi, "SELECT id_target, nama_dimensi FROM kokurikuler_target_dimensi WHERE id_kegiatan = ? ORDER BY id_target ASC");
        mysqli_stmt_bind_param($q_dimensi, "i", $id_kegiatan_pilih);
        mysqli_stmt_execute($q_dimensi);
        $daftar_dimensi = mysqli_fetch_all(mysqli_stmt_get_result($q_dimensi), MYSQLI_ASSOC);

        // 2. Ambil Siswa (Baris)
        $q_siswa = mysqli_prepare($koneksi, "SELECT id_siswa, nama_lengkap FROM siswa WHERE id_kelas = ? AND status_siswa = 'Aktif' ORDER BY nama_lengkap ASC");
        mysqli_stmt_bind_param($q_siswa, "i", $id_kelas_pilih);
        mysqli_stmt_execute($q_siswa);
        $daftar_siswa = mysqli_fetch_all(mysqli_stmt_get_result($q_siswa), MYSQLI_ASSOC);

        // 3. Ambil Nilai yang Sudah Ada (Untuk ditampilkan)
        // Kita hanya mengambil nilai dari guru yang sedang login (karena ini input mandiri)
        // ATAU jika ingin melihat nilai dari guru lain, kita perlu strategi.
        // Di sini kita asumsikan 1 siswa dinilai oleh 1 guru per kelas (atau tim sepakat). 
        // Agar aman, kita tampilkan nilai yang diinput oleh user ini.
        $q_nilai_exist = mysqli_query($koneksi, "
            SELECT id_target, id_siswa, nilai_kualitatif, catatan_guru 
            FROM kokurikuler_asesmen 
            WHERE id_guru_penilai = $id_guru_login
            AND id_target IN (SELECT id_target FROM kokurikuler_target_dimensi WHERE id_kegiatan = $id_kegiatan_pilih)
            AND id_siswa IN (SELECT id_siswa FROM siswa WHERE id_kelas = $id_kelas_pilih)
        ");
        
        $nilai_tersimpan = [];
        $catatan_tersimpan = [];
        while($row = mysqli_fetch_assoc($q_nilai_exist)) {
            $nilai_tersimpan[$row['id_siswa']][$row['id_target']] = $row['nilai_kualitatif'];
            $catatan_tersimpan[$row['id_siswa']][$row['id_target']] = $row['catatan_guru'];
        }
    ?>

    <form action="kokurikuler_aksi.php?aksi=simpan_asesmen" method="POST">
        <input type="hidden" name="id_kegiatan" value="<?php echo $id_kegiatan_pilih; ?>">
        <input type="hidden" name="id_kelas" value="<?php echo $id_kelas_pilih; ?>">
        
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white border-bottom py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 text-primary"><i class="bi bi-pencil-square me-2"></i>Lembar Penilaian</h5>
                    <!-- Legenda Singkat -->
                    <div class="small">
                        <span class="badge bg-success me-1">A</span>Sangat Baik
                        <span class="badge bg-primary me-1">B</span>Baik
                        <span class="badge bg-warning text-dark me-1">C</span>Cukup
                        <span class="badge bg-danger">K</span>Kurang
                    </div>
                </div>
            </div>
            
            <div class="card-body p-0">
                <div class="table-responsive" style="max-height: 70vh;">
                    <table class="table table-hover table-bordered table-assessment mb-0">
                        <thead>
                            <tr>
                                <th class="sticky-col align-middle text-center">Nama Siswa</th>
                                <?php foreach ($daftar_dimensi as $dimensi): ?>
                                <th class="horizontal-header">
                                    <div class="fw-bold mb-2"><?php echo htmlspecialchars($dimensi['nama_dimensi']); ?></div>
                                    <button type="button" class="btn btn-sm btn-outline-primary w-100 set-all-b" data-column="<?php echo $dimensi['id_target']; ?>">
                                        <i class="bi bi-check2-all"></i> Semua 'B'
                                    </button>
                                </th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($daftar_siswa as $siswa): ?>
                            <tr>
                                <td class="sticky-col align-middle fw-bold ps-3">
                                    <?php echo htmlspecialchars($siswa['nama_lengkap']); ?>
                                </td>
                                <?php foreach($daftar_dimensi as $dimensi): 
                                    $val = $nilai_tersimpan[$siswa['id_siswa']][$dimensi['id_target']] ?? ''; // Default kosong
                                    $cat = $catatan_tersimpan[$siswa['id_siswa']][$dimensi['id_target']] ?? '';
                                ?>
                                <td class="align-middle p-2" data-column="<?php echo $dimensi['id_target']; ?>">
                                    <!-- Hidden Input untuk Nilai -->
                                    <input type="hidden" name="nilai[<?php echo $siswa['id_siswa']; ?>][<?php echo $dimensi['id_target']; ?>]" 
                                           class="nilai-input" value="<?php echo htmlspecialchars($val); ?>">
                                    
                                    <!-- Tombol Pilihan Nilai -->
                                    <div class="value-buttons" data-siswa="<?php echo $siswa['id_siswa']; ?>" data-target="<?php echo $dimensi['id_target']; ?>">
                                        <button type="button" class="btn btn-nilai btn-sb <?php echo ($val == 'Sangat Baik') ? 'active' : ''; ?>" data-value="Sangat Baik">A</button>
                                        <button type="button" class="btn btn-nilai btn-b <?php echo ($val == 'Baik') ? 'active' : ''; ?>" data-value="Baik">B</button>
                                        <button type="button" class="btn btn-nilai btn-c <?php echo ($val == 'Cukup') ? 'active' : ''; ?>" data-value="Cukup">C</button>
                                        <button type="button" class="btn btn-nilai btn-k <?php echo ($val == 'Kurang') ? 'active' : ''; ?>" data-value="Kurang">K</button>
                                    </div>

                                    <!-- Input Catatan (Opsional) -->
                                    <textarea name="catatan[<?php echo $siswa['id_siswa']; ?>][<?php echo $dimensi['id_target']; ?>]" 
                                              class="form-control form-control-sm mt-1" rows="2" 
                                              placeholder="Catatan proses..."><?php echo htmlspecialchars($cat); ?></textarea>
                                </td>
                                <?php endforeach; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="sticky-footer">
                <div class="row align-items-center">
                    <div class="col-md-8 text-start text-muted small">
                        <i class="bi bi-info-circle me-1"></i> Pastikan semua nilai telah terisi sebelum menyimpan.
                    </div>
                    <div class="col-md-4 text-end">
                        <button type="submit" class="btn btn-success btn-lg px-5 shadow">
                            <i class="bi bi-save me-2"></i> Simpan Penilaian
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <?php elseif ($id_kegiatan_pilih > 0): ?>
        <div class="alert alert-info text-center mt-4">
            <i class="bi bi-arrow-up-circle fs-2 d-block mb-2"></i>
            Silakan pilih <strong>Kelas</strong> terlebih dahulu untuk memuat daftar siswa.
        </div>
    <?php endif; ?>

</div>

<script>
$(document).ready(function() {
    // 1. Inisialisasi Select2 (Pencarian Dropdown)
    $('.select2').select2({
        theme: 'bootstrap-5',
        width: '100%'
    });

    // 2. Logika Tombol Nilai (A, B, C, K)
    $(document).on('click', '.btn-nilai', function(e) {
        e.preventDefault(); // Mencegah submit form
        var btn = $(this);
        var group = btn.closest('.value-buttons');
        var input = group.siblings('.nilai-input');
        
        // Reset state aktif di grup ini
        group.find('.btn-nilai').removeClass('active');
        
        // Set state aktif tombol yg diklik
        btn.addClass('active');
        
        // Isi nilai ke hidden input
        input.val(btn.data('value'));
    });

    // 3. Logika "Set Semua B" per Kolom
    $('.set-all-b').on('click', function() {
        var colId = $(this).data('column');
        
        // Cari semua sel di kolom ini
        $('td[data-column="' + colId + '"]').each(function() {
            var cell = $(this);
            var btnB = cell.find('.btn-b');
            var input = cell.find('.nilai-input');
            
            // Jika belum ada nilai (kosong), set ke B. 
            // Opsional: Hapus kondisi if(input.val() == '') jika ingin menimpa semua nilai jadi B
            if(input.val() == '') { 
                cell.find('.btn-nilai').removeClass('active');
                btnB.addClass('active');
                input.val('Baik');
            }
        });
    });
});
</script>

<?php
if (isset($_SESSION['pesan'])) {
    $pesan_data = json_decode($_SESSION['pesan'], true);
    if (is_array($pesan_data)) {
        echo "<script>Swal.fire(" . json_encode($pesan_data) . ");</script>";
    }
    unset($_SESSION['pesan']);
}
include 'footer.php';
?>