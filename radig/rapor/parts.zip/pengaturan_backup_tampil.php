<?php
// Tampilkan Error (Untuk Debugging Whitepage)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Naikkan batas memori dan waktu eksekusi
ini_set('memory_limit', '512M');
set_time_limit(300); // 5 Menit

include 'header.php';
include 'koneksi.php';

// Validasi role admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<script>Swal.fire('Akses Ditolak','Hanya Admin yang dapat mengakses halaman ini.','error').then(() => window.location = 'dashboard.php');</script>";
    include 'footer.php';
    exit;
}

// ==================================================================================
// LOGIKA SINKRONISASI STRUKTUR (VERSI HEMAT MEMORI - STREAM READING)
// ==================================================================================
$sync_script = ""; 

if (isset($_POST['btn_sync_structure'])) {
    // Cek koneksi database
    if (isset($koneksi)) $db = $koneksi;
    elseif (isset($conn)) $db = $conn;
    elseif (isset($link)) $db = $link;

    if (isset($db) && isset($_FILES['sql_file_sync']) && $_FILES['sql_file_sync']['error'] == 0) {
        $file_tmp = $_FILES['sql_file_sync']['tmp_name'];
        
        // Variabel Laporan
        $report_created_tables = [];
        $report_added_columns = [];
        $report_existing_tables_count = 0;
        $report_existing_columns_count = 0;
        $report_errors = [];

        // Buka file dalam mode baca (Read-Only Stream) - Aman untuk file besar
        $handle = fopen($file_tmp, "r");
        
        if ($handle) {
            $in_table = false;
            $table_buffer = "";
            $current_table_name = "";

            while (($line = fgets($handle)) !== false) {
                $trim_line = trim($line);
                
                // Deteksi Awal CREATE TABLE
                if (stripos($trim_line, 'CREATE TABLE') === 0) {
                    $in_table = true;
                    $table_buffer = "";
                    
                    // Ambil nama tabel dari baris ini
                    if (preg_match('/CREATE TABLE\s+[`]?(\w+)[`]?/', $trim_line, $matches)) {
                        $current_table_name = $matches[1];
                    }
                }

                // Jika sedang di dalam blok CREATE TABLE, simpan barisnya
                if ($in_table) {
                    $table_buffer .= $line; // Jangan di-trim agar format terjaga jika perlu

                    // Deteksi Akhir CREATE TABLE (biasanya ) ENGINE=...)
                    if (preg_match('/\)\s*ENGINE=/i', $trim_line)) {
                        $in_table = false; // Selesai satu tabel
                        
                        // PROSES TABEL INI SEKARANG
                        if (!empty($current_table_name) && !empty($table_buffer)) {
                            
                            // 1. Cek Tabel di Database
                            $checkTable = $db->query("SHOW TABLES LIKE '$current_table_name'");
                            
                            if ($checkTable->num_rows == 0) {
                                // -> Tabel Belum Ada: Buat Baru
                                // Bersihkan trailing comma atau semicolon di akhir statement jika ada masalah parsing manual, 
                                // tapi biasanya full query dari dump sudah valid.
                                if ($db->query($table_buffer)) {
                                    $report_created_tables[] = $current_table_name;
                                } else {
                                    $report_errors[] = "Gagal membuat tabel <b>$current_table_name</b>: " . $db->error;
                                }
                            } else {
                                // -> Tabel Sudah Ada: Cek Kolom
                                $report_existing_tables_count++;
                                
                                // Ambil kolom yang ada di DB
                                $existingColumns = [];
                                $res = $db->query("SHOW COLUMNS FROM `$current_table_name`");
                                if ($res) {
                                    while($row = $res->fetch_assoc()) { 
                                        $existingColumns[] = strtolower($row['Field']); 
                                    }
                                }

                                // Parsing kolom dari buffer SQL (sederhana)
                                // Kita buang baris CREATE TABLE dan baris penutup ) ENGINE
                                $body_lines = explode("\n", $table_buffer);
                                foreach ($body_lines as $b_line) {
                                    $b_line = trim($b_line);
                                    
                                    // Skip baris kosong, baris CREATE TABLE awal, dan penutup
                                    if (empty($b_line) || stripos($b_line, 'CREATE TABLE') === 0 || stripos($b_line, ') ENGINE') === 0) continue;
                                    
                                    // Skip Key/Constraint
                                    if (preg_match('/^(PRIMARY KEY|KEY|UNIQUE|CONSTRAINT|FULLTEXT|FOREIGN KEY|\))/i', $b_line)) continue;
                                    
                                    // Ambil nama kolom (kata pertama yang diapit backtick atau tidak)
                                    if (preg_match('/^[`]?(\w+)[`]?/', $b_line, $colMatch)) {
                                        $colName = $colMatch[1];
                                        
                                        // Jika kolom tidak ada di DB -> Tambahkan
                                        if (!in_array(strtolower($colName), $existingColumns)) {
                                            // Bersihkan koma di akhir baris definisi kolom
                                            $colDefinition = rtrim($b_line, ',');
                                            
                                            if ($db->query("ALTER TABLE `$current_table_name` ADD $colDefinition")) {
                                                $report_added_columns[] = "Tabel <b>$current_table_name</b>: + Kolom <b>$colName</b>";
                                            } else {
                                                $report_errors[] = "Gagal alter tabel <b>$current_table_name</b> ($colName): " . $db->error;
                                            }
                                        } else {
                                            $report_existing_columns_count++;
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Reset untuk tabel berikutnya
                        $current_table_name = "";
                        $table_buffer = "";
                    }
                }
            }
            fclose($handle);
        } else {
            $report_errors[] = "Gagal membuka file sementara.";
        }

        // --- MENYUSUN LAPORAN HTML UNTUK SWEETALERT ---
        $html_report = "<div style='text-align:left; font-size:0.9rem; max-height:60vh; overflow-y:auto; overflow-x:hidden;'>";

        // Bagian 1: Perubahan Berhasil (Hijau)
        $hasChanges = (!empty($report_created_tables) || !empty($report_added_columns));
        
        if ($hasChanges) {
            $html_report .= "<div class='alert alert-success border-0 shadow-sm mb-3'>";
            $html_report .= "<h6 class='fw-bold mb-2 text-success'><i class='bi bi-check-circle-fill'></i> Berhasil Disinkronisasi:</h6>";
            $html_report .= "<ul class='mb-0 ps-3'>";
            foreach($report_created_tables as $t) {
                $html_report .= "<li>Membuat Tabel Baru: <b>$t</b></li>";
            }
            foreach($report_added_columns as $c) {
                $html_report .= "<li>$c</li>";
            }
            $html_report .= "</ul></div>";
        } else if (empty($report_errors)) {
            $html_report .= "<div class='alert alert-info border-0 shadow-sm text-center mb-3'>";
            $html_report .= "<h6 class='fw-bold mb-0 text-info'><i class='bi bi-check-circle-fill'></i> Database Sudah Identik</h6>";
            $html_report .= "<small>Tidak ditemukan tabel atau kolom baru di file SQL.</small>";
            $html_report .= "</div>";
        }

        // Bagian 2: Error (Merah) - Jika ada
        if (!empty($report_errors)) {
            $html_report .= "<div class='alert alert-danger border-0 shadow-sm mb-3'>";
            $html_report .= "<h6 class='fw-bold text-danger mb-2'>⚠️ Terjadi Kesalahan:</h6><ul class='mb-0 ps-3'>";
            foreach($report_errors as $err) {
                $html_report .= "<li>$err</li>";
            }
            $html_report .= "</ul></div>";
        }

        // Bagian 3: Status Data Lama (Biru/Abu)
        $html_report .= "<div class='p-2 bg-light rounded border-start border-4 border-primary'>";
        $html_report .= "<h6 class='fw-bold text-primary mb-1 small'>ℹ️ Status Data Lama (Aman):</h6>";
        $html_report .= "<ul class='list-unstyled mb-0 text-muted small'>";
        $html_report .= "<li><i class='bi bi-shield-check'></i> $report_existing_tables_count tabel sudah ada (tidak disentuh).</li>";
        $html_report .= "<li><i class='bi bi-shield-check'></i> $report_existing_columns_count kolom sudah sesuai (tidak disentuh).</li>";
        $html_report .= "</ul></div>";

        $html_report .= "</div>"; // Tutup container scroll

        $swal_icon = (!empty($report_errors)) ? 'warning' : 'success';
        $swal_title = ($hasChanges) ? 'Sinkronisasi Selesai' : 'Pemeriksaan Selesai';

        // MEMBUNGKUS SCRIPT AGAR JALAN SETELAH LOAD
        $sync_script = "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: '$swal_title',
                    html: `$html_report`,
                    icon: '$swal_icon',
                    width: '600px',
                    confirmButtonText: 'Tutup Laporan',
                    confirmButtonColor: '#0d6efd'
                });
            });
        </script>";
    } else {
        $error_msg = isset($_FILES['sql_file_sync']) ? "Error Code: " . $_FILES['sql_file_sync']['error'] : "File tidak terupload.";
        $sync_script = "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire('Gagal', 'Gagal membaca file upload. $error_msg', 'error');
            });
        </script>";
    }
}

// Logika membaca backup files
$backup_dir = 'backups/';
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0755, true);
}
$backup_files = glob($backup_dir . '*.sql');
rsort($backup_files);
?>

<style>
    .page-header { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); padding: 2.5rem 2rem; border-radius: 0.75rem; color: white; }
    .upload-box-success { border: 2px dashed var(--bs-success-border-subtle); background-color: var(--bs-success-bg-subtle); }
    .upload-box-primary { border: 2px dashed var(--bs-primary-border-subtle); background-color: var(--bs-primary-bg-subtle); }
    .upload-box-danger { border: 2px dashed var(--bs-danger-border-subtle); background-color: var(--bs-danger-bg-subtle); }
    .upload-box-warning { border: 2px dashed #ffc107; background-color: #fff3cd; } 
</style>

<div class="container-fluid">
    <!-- Output Script Hasil Sync Di Sini -->
    <?php echo $sync_script; ?>

    <div class="page-header text-white mb-4 shadow">
        <div class="d-sm-flex justify-content-between align-items-center">
            <div>
                <h1 class="mb-1">Database Management</h1>
                <p class="lead mb-0 opacity-75">Backup, Restore, Migrasi, dan Sinkronisasi Struktur.</p>
            </div>
            <a href="pengaturan_tampil.php" class="btn btn-outline-light mt-3 mt-sm-0"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
        </div>
    </div>

    <!-- Layout Grid 2x2 -->
    <div class="row g-4">
        
        <!-- 1. BUAT BACKUP -->
        <div class="col-md-6 col-lg-3">
            <div class="card shadow-sm h-100 upload-box-success">
                <div class="card-body text-center p-4 d-flex flex-column">
                    <div class="mb-3"><i class="bi bi-database-add text-success display-4"></i></div>
                    <h5>Backup Data</h5>
                    <p class="text-muted small flex-grow-1">Amankan data saat ini dengan membuat file cadangan (.sql) di server.</p>
                    <a href="pengaturan_aksi.php?aksi=buat_backup" class="btn btn-success w-100 mt-3"><i class="bi bi-download me-2"></i>Backup Sekarang</a>
                </div>
            </div>
        </div>

        <!-- 2. SINKRONISASI STRUKTUR (FITUR BARU) -->
        <div class="col-md-6 col-lg-3">
            <div class="card shadow-sm h-100 upload-box-warning">
                <form method="POST" enctype="multipart/form-data" id="form-sync">
                    <input type="hidden" name="btn_sync_structure" value="1"> <!-- Trigger Post -->
                    <div class="card-body text-center p-4 d-flex flex-column">
                        <div class="mb-3"><i class="bi bi-arrow-repeat text-warning display-4"></i></div>
                        <h5 class="text-warning-emphasis">Sync Struktur (Aman)</h5>
                        <p class="text-muted small flex-grow-1">
                            Perbarui struktur tabel/kolom agar sesuai file baru <strong>tanpa menghapus data lama</strong>.
                        </p>
                        <div class="mt-auto">
                            <input class="form-control form-control-sm mb-2" type="file" id="sql_file_sync" name="sql_file_sync" accept=".sql" required>
                            <button type="submit" class="btn btn-warning w-100"><i class="bi bi-magic me-2"></i>Sync Struktur</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- 3. MIGRASI DATA -->
        <div class="col-md-6 col-lg-3">
            <div class="card shadow-sm h-100 upload-box-primary">
                <form action="pengaturan_aksi.php" method="POST" enctype="multipart/form-data" id="form-migrasi">
                    <input type="hidden" name="aksi" value="migrasi_via_file">
                    <div class="card-body text-center p-4 d-flex flex-column">
                        <div class="mb-3"><i class="bi bi-box-arrow-in-down text-primary display-4"></i></div>
                        <h5 class="text-primary-emphasis">Migrasi Data</h5>
                        <p class="text-muted small flex-grow-1">
                            Impor data dari aplikasi lama. Database akan <strong>dikosongkan</strong> dulu.
                        </p>
                        <div class="mt-auto">
                            <input class="form-control form-control-sm mb-2" type="file" id="sql_file_migrasi" name="sql_file_migrasi" accept=".sql" required>
                            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-cloud-upload me-2"></i>Migrasi</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- 4. RESTORE TOTAL -->
        <div class="col-md-6 col-lg-3">
            <div class="card shadow-sm h-100 upload-box-danger">
                <form action="pengaturan_aksi.php" method="POST" enctype="multipart/form-data" id="form-restore-total">
                    <input type="hidden" name="aksi" value="lakukan_restore_total">
                    <div class="card-body text-center p-4 d-flex flex-column">
                        <div class="mb-3"><i class="bi bi-exclamation-octagon text-danger display-4"></i></div>
                        <h5 class="text-danger">Restore Total</h5>
                        <p class="text-muted small flex-grow-1">
                            <strong>BAHAYA!</strong> Menghapus total database dan mengganti dengan file ini.
                        </p>
                        <div class="mt-auto">
                            <input class="form-control form-control-sm mb-2" type="file" id="sql_file_restore" name="sql_file_restore" accept=".sql" required>
                            <button type="submit" class="btn btn-danger w-100"><i class="bi bi-trash-fill me-2"></i>Restore</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>

    <!-- Arsip File Backup -->
    <div class="card shadow-sm mt-4">
        <div class="card-header bg-white py-3">
            <h5 class="mb-0 card-title"><i class="bi bi-clock-history me-2"></i>Riwayat Backup Server</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Nama File</th>
                            <th>Waktu Backup</th>
                            <th class="text-end">Ukuran</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($backup_files)): ?>
                            <tr><td colspan="4" class="text-center text-muted p-4">Belum ada riwayat backup.</td></tr>
                        <?php else: ?>
                            <?php foreach ($backup_files as $file): ?>
                            <tr>
                                <td class="fw-bold text-primary"><i class="bi bi-file-earmark-code me-2"></i><?php echo htmlspecialchars(basename($file)); ?></td>
                                <td><?php echo date("d M Y, H:i", filemtime($file)); ?></td>
                                <td class="text-end"><?php echo round(filesize($file) / 1024, 2); ?> KB</td>
                                <td class="text-center">
                                    <a href="<?php echo $file; ?>" class="btn btn-sm btn-light border" data-bs-toggle="tooltip" title="Download" download><i class="bi bi-download text-primary"></i></a>
                                    <button onclick="hapusBackup('<?php echo urlencode(basename($file)); ?>')" class="btn btn-sm btn-light border" data-bs-toggle="tooltip" title="Hapus"><i class="bi bi-trash text-danger"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) { return new bootstrap.Tooltip(tooltipTriggerEl); });

    // Konfirmasi Sync Struktur
    const formSync = document.getElementById('form-sync');
    if(formSync) {
        formSync.addEventListener('submit', function (e) {
            e.preventDefault();
            if(document.getElementById('sql_file_sync').files.length === 0) {
                Swal.fire('Pilih File', 'Silakan pilih file .sql database baru terlebih dahulu.', 'warning');
                return;
            }
            Swal.fire({
                title: 'Mulai Sinkronisasi?',
                html: "Sistem akan mengecek tabel/kolom baru dan menambahkannya.<br>Data lama <b>AMAN</b> (Tidak dihapus).",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#ffc107',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, Cek & Sinkronkan!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        title: 'Memproses...',
                        text: 'Sedang membandingkan struktur database.',
                        allowOutsideClick: false,
                        didOpen: () => { Swal.showLoading(); }
                    });
                    e.target.submit();
                }
            });
        });
    }

    // Konfirmasi Migrasi (Data Hilang)
    const formMigrasi = document.getElementById('form-migrasi');
    if(formMigrasi) {
        formMigrasi.addEventListener('submit', function (e) {
            e.preventDefault();
            if(document.getElementById('sql_file_migrasi').files.length === 0) {
                Swal.fire('Pilih File', 'Silakan pilih file .sql terlebih dahulu.', 'warning');
                return;
            }
            Swal.fire({
                title: 'Hapus Data Lama & Migrasi?',
                html: "Database saat ini akan <b>DIKOSONGKAN</b> dan diganti dengan isi file ini.<br>Pastikan ini file backup yang benar.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#0d6efd',
                confirmButtonText: 'Ya, Migrasi',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({ title: 'Memproses...', didOpen: () => { Swal.showLoading(); } });
                    e.target.submit();
                }
            });
        });
    }

    // Konfirmasi Restore (Data Hilang Total)
    const formRestore = document.getElementById('form-restore-total');
    if(formRestore) {
        formRestore.addEventListener('submit', function (e) {
            e.preventDefault();
            if(document.getElementById('sql_file_restore').files.length === 0) {
                Swal.fire('Pilih File', 'Silakan pilih file .sql terlebih dahulu.', 'warning');
                return;
            }
            Swal.fire({
                title: 'PERINGATAN KERAS!',
                html: "Tindakan ini akan <b>MENGHAPUS SELURUH DATABASE</b> server ini dan menimpanya.<br>Data yang tidak ada di file backup akan HILANG PERMANEN.",
                icon: 'error',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                confirmButtonText: 'Saya Paham, Lanjutkan',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({ title: 'Memproses Restore...', didOpen: () => { Swal.showLoading(); } });
                    e.target.submit();
                }
            });
        });
    }
});

function hapusBackup(namaFile) {
    Swal.fire({
        title: 'Hapus Backup?', text: "File ini tidak bisa dikembalikan!", icon: 'warning',
        showCancelButton: true, confirmButtonColor: '#d33', confirmButtonText: 'Hapus'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'pengaturan_aksi.php?aksi=hapus_backup&file=' + namaFile;
        }
    });
}
</script>

<?php include 'footer.php'; ?>