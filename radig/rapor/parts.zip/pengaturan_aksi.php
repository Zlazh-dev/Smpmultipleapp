<?php
session_start();
include 'koneksi.php';

// Pastikan hanya admin yang bisa mengakses
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Akses ditolak. Anda harus login sebagai admin.");
}

// Mengambil aksi dari GET atau POST
$aksi = $_GET['aksi'] ?? $_POST['aksi'] ?? ''; 

// Fungsi helper untuk pesan JSON SweetAlert
function set_json_pesan($tipe, $judul, $teks) {
    return json_encode(['icon' => $tipe, 'title' => $judul, 'text' => $teks]);
}

// Fungsi Helper: Simpan Pengaturan ke DB (Insert/Update)
function simpanPengaturan($koneksi, $nama, $nilai) {
    $stmt = mysqli_prepare($koneksi, "INSERT INTO pengaturan (nama_pengaturan, nilai_pengaturan) VALUES (?, ?) ON DUPLICATE KEY UPDATE nilai_pengaturan = VALUES(nilai_pengaturan)");
    mysqli_stmt_bind_param($stmt, "ss", $nama, $nilai);
    mysqli_stmt_execute($stmt);
}

// Fungsi helper untuk upload file
function handleFileUpload($file_key, $upload_dir, $allowed_types, $field_name) {
    // Cek keberadaan file di $_FILES
    if (!isset($_FILES[$file_key])) {
        return null;
    }

    if ($_FILES[$file_key]['error'] == 0) {
        $file = $_FILES[$file_key];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($file_ext, $allowed_types)) {
            $_SESSION['pesan'] = set_json_pesan('error', 'Upload Gagal', "Format file untuk $field_name tidak diizinkan. Harap unggah " . implode(', ', $allowed_types));
            return null;
        }
        
        // Limit ukuran file (Logo/Watermark 1MB, KOP 2MB)
        $is_kop = strpos($field_name, 'kop') !== false;
        $limit = $is_kop ? 2097152 : 1048576; // 2MB untuk KOP
        $limit_text = $is_kop ? '2MB' : '1MB';

        if ($file['size'] > $limit) { 
             $_SESSION['pesan'] = set_json_pesan('error', 'Upload Gagal', "Ukuran file $field_name terlalu besar. Maksimal $limit_text.");
            return null;
        }
        
        $new_filename = $field_name . '_' . time() . '.' . $file_ext;
        $destination = $upload_dir . $new_filename;
        
        if (move_uploaded_file($file['tmp_name'], $destination)) {
            return $new_filename;
        } else {
            $_SESSION['pesan'] = set_json_pesan('error', 'Upload Gagal', "Gagal memindahkan file $field_name.");
            return null;
        }
    }
    return null; 
}

// ==============================================
// === FUNGSI UNTUK MENJALANKAN SKRIP MIGRASI ===
// ==============================================
function jalankan_skrip_migrasi($koneksi, &$errors) {
    // 1. Ubah KKM dari 75 (lama) menjadi 50 (baru)
    $sql1 = "UPDATE `pengaturan` SET `nilai_pengaturan` = '50' WHERE `nama_pengaturan` = 'kkm'";
    if (!mysqli_query($koneksi, $sql1)) $errors[] = "Gagal update KKM: " . mysqli_error($koneksi);

    // 2. Tambah Pengaturan Baru
    $sql2 = "INSERT INTO `pengaturan` (nama_pengaturan, nilai_pengaturan) VALUES 
             ('rapor_ukuran_kertas', 'F4'),
             ('rapor_skema_warna', 'light_green'),
             ('tanggal_rapor_pts', '2025-09-10'),
             ('kop_sekolah', ''),
             ('cetak_tanpa_kop', '0'),
             ('margin_atas_tanpa_kop', '0'),
             ('rapor_tampil_kop', '0')
             ON DUPLICATE KEY UPDATE nilai_pengaturan = VALUES(nilai_pengaturan)";
    if (!mysqli_query($koneksi, $sql2)) $errors[] = "Gagal tambah pengaturan baru: " . mysqli_error($koneksi);

    // 3. Ubah 'Seni Musik' menjadi 'Seni Rupa'
    $sql3 = "UPDATE `mata_pelajaran` SET `nama_mapel` = 'Seni Rupa', `urutan` = 14 WHERE `id_mapel` = 8";
    if (!mysqli_query($koneksi, $sql3)) $errors[] = "Gagal update Seni Rupa: " . mysqli_error($koneksi);

    // 4. Update urutan mapel
    $sql4 = "UPDATE `mata_pelajaran` SET `urutan` = CASE `id_mapel`
                WHEN 1 THEN 11
                WHEN 2 THEN 1
                WHEN 3 THEN 6
                WHEN 4 THEN 7
                WHEN 5 THEN 8
                WHEN 6 THEN 9
                WHEN 7 THEN 10
                WHEN 9 THEN 15
                WHEN 10 THEN 13
                WHEN 11 THEN 16
                WHEN 12 THEN 12
                WHEN 13 THEN 2
                ELSE `urutan`
             END
             WHERE `id_mapel` IN (1,2,3,4,5,6,7,9,10,11,12,13)";
    if (!mysqli_query($koneksi, $sql4)) $errors[] = "Gagal update urutan mapel: " . mysqli_error($koneksi);

    // 5. Tambah mapel agama baru
    $sql5 = "INSERT IGNORE INTO `mata_pelajaran` (`id_mapel`, `nama_mapel`, `kode_mapel`, `urutan`) VALUES
             (17, 'Pendidikan Agama Hindu dan Budi Pekerti', 'PAH', 4),
             (15, 'Pendidikan Agama Budha dan Budi Pekerti', 'PAB', 3),
             (16, 'Pendidikan Agama Katolik dan Budi Pekerti', 'PAKK', 5)";
    if (!mysqli_query($koneksi, $sql5)) $errors[] = "Gagal tambah mapel agama baru: " . mysqli_error($koneksi);
}
// ==============================================


switch ($aksi) {
    // 1. Update Sekolah
    case 'update_sekolah':
        $stmt = mysqli_prepare($koneksi, "UPDATE sekolah SET 
            nama_sekolah=?, jenjang=?, npsn=?, nss=?, jalan=?, desa_kelurahan=?, 
            kecamatan=?, kabupaten_kota=?, provinsi=?, telepon=?, email=?, website=? 
            WHERE id_sekolah = 1");
        mysqli_stmt_bind_param($stmt, "ssssssssssss", 
            $_POST['nama_sekolah'], $_POST['jenjang'], $_POST['npsn'], $_POST['nss'], 
            $_POST['jalan'], $_POST['desa_kelurahan'], $_POST['kecamatan'], 
            $_POST['kabupaten_kota'], $_POST['provinsi'], $_POST['telepon'], 
            $_POST['email'], $_POST['website']
        );
        if(mysqli_stmt_execute($stmt)){
            $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Data identitas sekolah telah diperbarui.');
        } else {
            $_SESSION['pesan'] = set_json_pesan('error', 'Gagal!', 'Terjadi kesalahan: ' . mysqli_error($koneksi));
        }
        header("Location: pengaturan_tampil.php");
        exit();
        break;

    // 2. Update Pejabat
    case 'update_pejabat':
        $stmt = mysqli_prepare($koneksi, "UPDATE sekolah SET nama_kepsek=?, jabatan_kepsek=?, nip_kepsek=? WHERE id_sekolah = 1");
        mysqli_stmt_bind_param($stmt, "sss", $_POST['nama_kepsek'], $_POST['jabatan_kepsek'], $_POST['nip_kepsek']);
        if(mysqli_stmt_execute($stmt)){
            $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Data pejabat telah diperbarui.');
        } else {
            $_SESSION['pesan'] = set_json_pesan('error', 'Gagal!', 'Terjadi kesalahan saat menyimpan data pejabat.');
        }
        header("Location: pengaturan_tampil.php");
        exit();
        break;

    // 3. Update Pengaturan Umum
    case 'update_pengaturan':
        if (isset($_POST['pengaturan']) && is_array($_POST['pengaturan'])) {
            foreach ($_POST['pengaturan'] as $nama => $nilai) {
                simpanPengaturan($koneksi, $nama, $nilai);
            }
            $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Pengaturan rapor telah disimpan.');
        }
        header("Location: pengaturan_tampil.php");
        exit();
        break;

    // 4. Tambah Tahun Ajaran
    case 'tambah_ta':
        $tahun_ajaran = $_POST['tahun_ajaran'] ?? '';
        if (!empty($tahun_ajaran)) {
            $stmt = mysqli_prepare($koneksi, "INSERT INTO tahun_ajaran (tahun_ajaran, status) VALUES (?, 'Tidak Aktif')");
            mysqli_stmt_bind_param($stmt, "s", $tahun_ajaran);
            if(mysqli_stmt_execute($stmt)){
                $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Tahun ajaran baru ditambahkan.');
            } else {
                 $_SESSION['pesan'] = set_json_pesan('error', 'Gagal!', 'Gagal menambah tahun ajaran.');
            }
        }
        header("Location: pengaturan_tampil.php");
        exit();
        break;

    // 5. Aktifkan TA
    case 'aktifkan_ta':
        $id_ta = $_GET['id'] ?? 0;
        if ($id_ta > 0) {
            mysqli_query($koneksi, "UPDATE tahun_ajaran SET status = 'Tidak Aktif'");
            $stmt = mysqli_prepare($koneksi, "UPDATE tahun_ajaran SET status = 'Aktif' WHERE id_tahun_ajaran = ?");
            mysqli_stmt_bind_param($stmt, "i", $id_ta);
            if(mysqli_stmt_execute($stmt)){
                $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Tahun ajaran diaktifkan.');
            }
        }
        header("Location: pengaturan_tampil.php");
        exit();
        break;

    // 6. Update Logo
    case 'update_logo':
        $upload_dir = 'uploads/';
        $new_logo_name = handleFileUpload('logo_sekolah', $upload_dir, ['jpg', 'jpeg', 'png'], 'logo');
        if ($new_logo_name) {
            $q = mysqli_query($koneksi, "SELECT logo_sekolah FROM sekolah WHERE id_sekolah = 1");
            $d = mysqli_fetch_assoc($q);
            if (!empty($d['logo_sekolah']) && file_exists($upload_dir . $d['logo_sekolah'])) unlink($upload_dir . $d['logo_sekolah']);
            
            $stmt = mysqli_prepare($koneksi, "UPDATE sekolah SET logo_sekolah = ? WHERE id_sekolah = 1");
            mysqli_stmt_bind_param($stmt, "s", $new_logo_name);
            mysqli_stmt_execute($stmt);
            $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Logo sekolah diperbarui.');
        }
        header("Location: pengaturan_tampil.php");
        exit();
        break;

    // =========================================================================
    // === 7. FITUR UTAMA: SIMPAN PENGATURAN KOP (KOMPATIBILITAS PENUH) ===
    // =========================================================================
    case 'simpan_kop':
    case 'update_kop_gambar': 
        $upload_dir = 'uploads/';
        
        // A. Simpan Data Teks (Warna, Kertas, dll)
        if (isset($_POST['pengaturan']) && is_array($_POST['pengaturan'])) {
            foreach ($_POST['pengaturan'] as $nama => $nilai) {
                simpanPengaturan($koneksi, $nama, $nilai);
            }
        }

        // B. Simpan Data KOP Baru (Toggle & Margin)
        // [PERBAIKAN UTAMA DI SINI]
        // Kita cek apakah nilainya == '1'. Ini menangani kasus adanya input hidden value='0'.
        // Jika checkbox dicentang, browser kirim '1'. Jika tidak, browser kirim '0' (dari hidden) atau tidak kirim sama sekali.
        
        $cetak_tanpa_kop = (isset($_POST['cetak_tanpa_kop']) && $_POST['cetak_tanpa_kop'] == '1') ? '1' : '0';
        $margin_atas = $_POST['margin_atas_tanpa_kop'] ?? '0';
        
        // PERBAIKAN PENTING:
        // Cek nilai '1' secara eksplisit
        $rapor_tampil_kop = (isset($_POST['rapor_tampil_kop']) && $_POST['rapor_tampil_kop'] == '1') ? '1' : '0';

        simpanPengaturan($koneksi, 'cetak_tanpa_kop', $cetak_tanpa_kop);
        simpanPengaturan($koneksi, 'margin_atas_tanpa_kop', $margin_atas);
        simpanPengaturan($koneksi, 'rapor_tampil_kop', $rapor_tampil_kop);

        // C. Handle Upload KOP (Deteksi nama input yang berbeda)
        // Deteksi input 'file_kop' (baru) atau 'file_kop_sekolah' (lama)
        $input_name = 'file_kop'; 
        if (!isset($_FILES['file_kop']) && isset($_FILES['file_kop_sekolah'])) {
            $input_name = 'file_kop_sekolah';
        }

        $new_kop_name = handleFileUpload($input_name, $upload_dir, ['jpg', 'jpeg', 'png'], 'kop_sekolah');
        
        if ($new_kop_name) {
            // Hapus file lama (Cek kedua key DB)
            $keys = ['kop_sekolah', 'file_kop_sekolah'];
            foreach ($keys as $key) {
                $q = mysqli_query($koneksi, "SELECT nilai_pengaturan FROM pengaturan WHERE nama_pengaturan = '$key'");
                $d = mysqli_fetch_assoc($q);
                if ($d && !empty($d['nilai_pengaturan']) && file_exists($upload_dir . $d['nilai_pengaturan'])) {
                    unlink($upload_dir . $d['nilai_pengaturan']);
                }
            }

            // Simpan ke KEDUA key agar rapor lama dan baru tetap jalan
            simpanPengaturan($koneksi, 'kop_sekolah', $new_kop_name);
            simpanPengaturan($koneksi, 'file_kop_sekolah', $new_kop_name);

            $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Gambar KOP berhasil diupload dan disimpan.');
        } else {
            $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Pengaturan KOP disimpan.');
        }
        
        header("Location: pengaturan_tampil.php");
        exit();
        break;

    // 8. Upload Watermark
    case 'simpan_watermark': 
    case 'update_watermark':
        $upload_dir = 'uploads/';
        $watermark_lama = $_POST['watermark_lama'] ?? null;
        
        if (isset($_POST['hapus_watermark']) && $_POST['hapus_watermark'] == '1') {
            if (!empty($watermark_lama) && file_exists($upload_dir . $watermark_lama)) unlink($upload_dir . $watermark_lama);
            simpanPengaturan($koneksi, 'watermark_file', '');
            $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Watermark dihapus.');
        } else {
            $input_wm = isset($_FILES['file_watermark']) ? 'file_watermark' : (isset($_FILES['watermark_baru']) ? 'watermark_baru' : 'file_watermark');
            $new_wm = handleFileUpload($input_wm, $upload_dir, ['png'], 'watermark');
            
            if ($new_wm) {
                if (!empty($watermark_lama) && file_exists($upload_dir . $watermark_lama)) unlink($upload_dir . $watermark_lama);
                simpanPengaturan($koneksi, 'watermark_file', $new_wm);
                $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil!', 'Watermark diperbarui.');
            } else {
                 $_SESSION['pesan'] = set_json_pesan('info', 'Info', 'Tidak ada file watermark dipilih.');
            }
        }
        header("Location: pengaturan_tampil.php");
        exit();
        break;

    // 9. Aksi untuk membuat file backup
    case 'buat_backup':
        global $host, $user, $pass, $db; 
        $db_host = $host ?? 'localhost'; $db_user = $user ?? 'root'; $db_pass = $pass ?? ''; $db_name = $db ?? 'raporsmp';
        try {
            $mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);
            if ($mysqli->connect_error) { throw new Exception('Koneksi database gagal: ' . $mysqli->connect_error); }
            $mysqli->set_charset("utf8mb4");
            
            $backup_content = "-- Rapor Digital Backup (Pure PHP Method)\n-- Host: {$db_host}\n-- Waktu: " . date('Y-m-d H:i:s') . "\n-- Database: `{$db_name}`\n-- ------------------------------------------------------\n\n";
            
            $tables = []; $result = $mysqli->query("SHOW TABLES");
            while ($row = $result->fetch_row()) { $tables[] = $row[0]; }
            
            foreach ($tables as $table) {
                $result_struktur = $mysqli->query("SHOW CREATE TABLE `{$table}`"); $row_struktur = $result_struktur->fetch_row();
                $backup_content .= "DROP TABLE IF EXISTS `{$table}`;\n"; $backup_content .= $row_struktur[1] . ";\n\n";
                
                $result_data = $mysqli->query("SELECT * FROM `{$table}`"); 
                if($result_data === false) continue; 
                
                $num_fields = $result_data->field_count;
                if ($result_data->num_rows > 0) {
                    while ($row = $result_data->fetch_row()) {
                        $backup_content .= "INSERT INTO `{$table}` VALUES(";
                        for ($j = 0; $j < $num_fields; $j++) {
                            if (isset($row[$j])) { 
                                $row[$j] = $mysqli->real_escape_string($row[$j]);
                                $backup_content .= "'{$row[$j]}'"; 
                            } else { $backup_content .= "NULL"; }
                            if ($j < ($num_fields - 1)) { $backup_content .= ','; }
                        }
                        $backup_content .= ");\n";
                    }
                    $backup_content .= "\n";
                }
            }
            $mysqli->close();
            
            $backup_dir = 'backups/'; if (!is_dir($backup_dir)) { mkdir($backup_dir, 0755, true); }
            $nama_file = 'backup_' . $db_name . '_' . date('Y-m-d_H-i-s') . '.sql';
            if(file_put_contents($backup_dir . $nama_file, $backup_content) === false) {
                 throw new Exception('Gagal menulis file backup. Periksa izin folder.');
            }
            
            $_SESSION['pesan'] = set_json_pesan('success', 'Backup Berhasil', 'File backup ' . $nama_file . ' berhasil dibuat.');
        } catch (Exception $e) { 
            $_SESSION['pesan'] = set_json_pesan('error', 'Backup Gagal', 'Terjadi kesalahan: ' . $e->getMessage()); 
        }
        header('Location: pengaturan_backup_tampil.php');
        exit;
        break;
    
    // 10. Aksi untuk Restore Total
    case 'lakukan_restore_total':
        global $koneksi; 

        if (!isset($_FILES['sql_file_restore']) || $_FILES['sql_file_restore']['error'] != UPLOAD_ERR_OK) {
            $_SESSION['pesan'] = set_json_pesan('error', 'Upload Gagal', 'Tidak ada file SQL yang diunggah atau terjadi error.');
            header('Location: pengaturan_backup_tampil.php');
            exit;
        }

        $file_path = $_FILES['sql_file_restore']['tmp_name'];

        try {
            set_time_limit(0); 
            mysqli_query($koneksi, "SET foreign_key_checks = 0");
            mysqli_query($koneksi, "SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");

            $tables = [];
            $result = mysqli_query($koneksi, "SHOW TABLES");
            if (!$result) { throw new Exception("Gagal mendapatkan daftar tabel: " . mysqli_error($koneksi)); }
            while ($row = mysqli_fetch_row($result)) {
                $tables[] = $row[0];
            }

            foreach ($tables as $table) {
                if (!mysqli_query($koneksi, "DROP TABLE IF EXISTS `{$table}`")) {
                    throw new Exception("Gagal menghapus tabel `{$table}`: " . mysqli_error($koneksi));
                }
            }

            $query_buffer = '';
            $file_handle = fopen($file_path, 'r');
            if (!$file_handle) { throw new Exception("Gagal membaca file SQL yang diunggah."); }

            while (($line = fgets($file_handle)) !== false) {
                $line_trimmed = trim($line);
                if (empty($line_trimmed) || substr($line_trimmed, 0, 2) == '--' || substr($line_trimmed, 0, 1) == '#') {
                    continue;
                }
                $query_buffer .= $line;
                if (substr($line_trimmed, -1, 1) == ';') {
                    if (!mysqli_query($koneksi, $query_buffer)) {
                         $errors[] = "Query gagal: " . mysqli_error($koneksi); 
                    }
                    $query_buffer = ''; 
                }
            }
            fclose($file_handle);

            mysqli_query($koneksi, "SET foreign_key_checks = 1");
            $_SESSION['pesan'] = set_json_pesan('success', 'Restore Total Berhasil', 'Database telah berhasil dipulihkan dari file unggahan.');

        } catch (Exception $e) {
            mysqli_query($koneksi, "SET foreign_key_checks = 1");
            $_SESSION['pesan'] = set_json_pesan('error', 'Restore Gagal Total', 'Terjadi kesalahan: ' . $e->getMessage());
        }
        
        header('Location: pengaturan_backup_tampil.php');
        exit;
        break;

    // 11. Aksi untuk menghapus file backup
    case 'hapus_backup':
        $backup_dir = 'backups/';
        $file_name = urldecode($_GET['file']);
        if (basename($file_name) == $file_name) {
            $file_path = $backup_dir . $file_name;
            if (file_exists($file_path)) {
                unlink($file_path);
                $_SESSION['pesan'] = set_json_pesan('success', 'Berhasil', 'File backup telah dihapus.');
            } else {
                $_SESSION['pesan'] = set_json_pesan('error', 'Gagal', 'File tidak ditemukan.');
            }
        } else {
             $_SESSION['pesan'] = set_json_pesan('error', 'Akses Ditolak', 'Nama file tidak valid.');
        }
        header('Location: pengaturan_backup_tampil.php');
        exit;
        break;

    // 12. AKSI MIGRASI VIA FILE
    case 'migrasi_via_file':
        global $koneksi;
        $errors = [];
        set_time_limit(0); 

        if (!isset($_FILES['sql_file_migrasi']) || $_FILES['sql_file_migrasi']['error'] != UPLOAD_ERR_OK) {
            $_SESSION['pesan'] = set_json_pesan('error', 'Upload Gagal', 'Tidak ada file SQL migrasi yang diunggah.');
            header('Location: pengaturan_backup_tampil.php');
            exit;
        }

        $file_path = $_FILES['sql_file_migrasi']['tmp_name'];

        try {
            mysqli_query($koneksi, "SET foreign_key_checks = 0");
            mysqli_query($koneksi, "SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");
            
            $tables = [];
            $result = mysqli_query($koneksi, "SHOW TABLES");
            if (!$result) throw new Exception("Gagal mendapatkan daftar tabel: " . mysqli_error($koneksi));
            
            while ($row = mysqli_fetch_row($result)) { $tables[] = $row[0]; }
            
            foreach ($tables as $table) {
                if (!mysqli_query($koneksi, "DROP TABLE IF EXISTS `{$table}`")) {
                   $errors[] = "Gagal menghapus tabel `{$table}`: " . mysqli_error($koneksi);
                }
            }

            $query_buffer = '';
            $file_handle = fopen($file_path, 'r');
            if (!$file_handle) throw new Exception("Gagal membaca file SQL yang diunggah.");

            while (($line = fgets($file_handle)) !== false) {
                $line_trimmed = trim($line);
                if (empty($line_trimmed) || substr($line_trimmed, 0, 2) == '--' || substr($line_trimmed, 0, 1) == '#') continue;
                $query_buffer .= $line;
                if (substr($line_trimmed, -1, 1) == ';') {
                    if (!mysqli_query($koneksi, $query_buffer)) {
                        $errors[] = "Query gagal (error minor): " . substr(mysqli_error($koneksi), 0, 100);
                    }
                    $query_buffer = ''; 
                }
            }
            fclose($file_handle);
            
            // JALANKAN MIGRASI STRUKTURAL (ALTER & CREATE)
            $cek_kolom_sql = "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'kokurikuler_kegiatan' AND COLUMN_NAME = 'id_koordinator'";
            $hasil_cek = mysqli_query($koneksi, $cek_kolom_sql);

            if ($hasil_cek && mysqli_num_rows($hasil_cek) == 0) {
                $sql_alter1 = "ALTER TABLE `kokurikuler_kegiatan` ADD COLUMN `id_koordinator` INT DEFAULT NULL AFTER `bentuk_kegiatan`, ADD KEY `fk_kegiatan_koordinator` (`id_koordinator`), ADD CONSTRAINT `fk_kegiatan_koordinator` FOREIGN KEY (`id_koordinator`) REFERENCES `guru` (`id_guru`) ON DELETE SET NULL ON UPDATE CASCADE";
                if (!mysqli_query($koneksi, $sql_alter1)) { $errors[] = "Gagal alter kokurikuler_kegiatan: " . mysqli_error($koneksi); }
            }

            $sql_create1 = "CREATE TABLE IF NOT EXISTS `kokurikuler_mapel_terlibat` ( `id_kegiatan` int NOT NULL, `id_mapel` int NOT NULL, PRIMARY KEY (`id_kegiatan`,`id_mapel`), KEY `fk_mapel_mapel` (`id_mapel`), CONSTRAINT `fk_mapel_kegiatan` FOREIGN KEY (`id_kegiatan`) REFERENCES `kokurikuler_kegiatan` (`id_kegiatan`) ON DELETE CASCADE ON UPDATE CASCADE, CONSTRAINT `fk_mapel_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `mata_pelajaran` (`id_mapel`) ON DELETE CASCADE ON UPDATE CASCADE ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
            if (!mysqli_query($koneksi, $sql_create1)) { $errors[] = "Gagal create kokurikuler_mapel_terlibat: " . mysqli_error($koneksi); }

            $sql_create2 = "CREATE TABLE IF NOT EXISTS `kokurikuler_tim_penilai` ( `id_kegiatan` int NOT NULL, `id_guru` int NOT NULL, PRIMARY KEY (`id_kegiatan`,`id_guru`), KEY `fk_tim_guru` (`id_guru`), CONSTRAINT `fk_tim_guru` FOREIGN KEY (`id_guru`) REFERENCES `guru` (`id_guru`) ON DELETE CASCADE ON UPDATE CASCADE, CONSTRAINT `fk_tim_kegiatan` FOREIGN KEY (`id_kegiatan`) REFERENCES `kokurikuler_kegiatan` (`id_kegiatan`) ON DELETE CASCADE ON UPDATE CASCADE ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
            if (!mysqli_query($koneksi, $sql_create2)) { $errors[] = "Gagal create kokurikuler_tim_penilai: " . mysqli_error($koneksi); }

            // JALANKAN SKRIP MIGRASI DATA
            jalankan_skrip_migrasi($koneksi, $errors);

            // Pembersihan Data
            mysqli_query($koneksi, "UPDATE `siswa` SET `jenis_kelamin` = NULL WHERE `jenis_kelamin` = ''");
            mysqli_query($koneksi, "SET foreign_key_checks = 1");

            if (empty($errors)) {
                $_SESSION['pesan'] = set_json_pesan('success', 'Migrasi Berhasil!', 'Data lama Anda telah berhasil diimpor dan diperbarui ke struktur baru.');
            } else {
                 $error_string = implode('; ', array_slice($errors, 0, 3)); 
                 $_SESSION['pesan'] = set_json_pesan('warning', 'Migrasi Selesai (dengan error)', 'Data diimpor, tapi terjadi beberapa error: ' . $error_string . '...');
            }

        } catch (Exception $e) {
            mysqli_query($koneksi, "SET foreign_key_checks = 1"); 
            $_SESSION['pesan'] = set_json_pesan('error', 'Migrasi Gagal Total', 'Terjadi kesalahan: ' . $e->getMessage());
        }

        header('Location: pengaturan_backup_tampil.php');
        exit;
        break;

    // Aksi default
    default:
        header("Location: pengaturan_tampil.php");
        exit();
        break;
}
?>