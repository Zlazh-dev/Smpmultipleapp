<?php
// dashboard_siswa.php - Konten khusus untuk Siswa (TEAL THEME)

// Pastikan koneksi sudah ada
if (!isset($koneksi)) { die('File ini tidak boleh diakses langsung.'); }

// =================================================================================
// 1. LOGIKA DATA (BACKEND) - TETAP SAMA
// =================================================================================

// Ambil data tahun ajaran aktif
$q_ta_aktif = mysqli_query($koneksi, "SELECT id_tahun_ajaran, tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
$data_tahun_aktif = mysqli_fetch_assoc($q_ta_aktif);
$id_tahun_ajaran_aktif = $data_tahun_aktif['id_tahun_ajaran'] ?? 0;
$nama_tahun_ajaran_aktif = $data_tahun_aktif['tahun_ajaran'] ?? 'Tidak Aktif';

// Ambil semester aktif
$q_smt = mysqli_query($koneksi, "SELECT nilai_pengaturan FROM pengaturan WHERE nama_pengaturan = 'semester_aktif' LIMIT 1");
$semester_aktif = mysqli_fetch_assoc($q_smt)['nilai_pengaturan'] ?? 1;
$semester_text = ($semester_aktif == 1) ? 'Ganjil' : 'Genap';

// Ambil data siswa yang login dari session
$id_siswa = $_SESSION['id_siswa'] ?? 0;
$nama_siswa = $_SESSION['nama_siswa'] ?? 'Siswa';

if ($id_siswa == 0) {
     echo "<div class='alert alert-danger'>Error: Data siswa tidak ditemukan. Silakan login kembali.</div>";
     include 'footer.php';
     exit;
}

// Ambil detail data siswa
$query_siswa_detail = mysqli_prepare($koneksi,
    "SELECT s.nisn, s.nis, s.foto_siswa, k.nama_kelas, k.fase
     FROM siswa s
     LEFT JOIN kelas k ON s.id_kelas = k.id_kelas
     WHERE s.id_siswa = ?");
mysqli_stmt_bind_param($query_siswa_detail, "i", $id_siswa);
mysqli_stmt_execute($query_siswa_detail);
$siswa_detail = mysqli_fetch_assoc(mysqli_stmt_get_result($query_siswa_detail));
mysqli_stmt_close($query_siswa_detail);

// Tentukan path foto profil siswa
$foto_profil_siswa = 'assets/img/avatar/avatar-1.png'; // Default avatar
if (!empty($siswa_detail['foto_siswa'])) {
    $path_to_check = 'uploads/foto_siswa/' . $siswa_detail['foto_siswa'];
    if (file_exists($path_to_check)) {
        $foto_profil_siswa = $path_to_check;
    }
}

// Cek status rapor terakhir siswa
$rapor_final = false;
$data_kehadiran = ['sakit' => 0, 'izin' => 0, 'tanpa_keterangan' => 0];
$catatan_wali = 'Belum ada catatan dari Wali Kelas.';
$id_rapor_siswa = null;

$query_rapor_status = mysqli_prepare($koneksi,
    "SELECT id_rapor, status, sakit, izin, tanpa_keterangan, catatan_wali_kelas
     FROM rapor
     WHERE id_siswa = ? AND semester = ? AND id_tahun_ajaran = ?
     ORDER BY id_rapor DESC LIMIT 1");
mysqli_stmt_bind_param($query_rapor_status, "iii", $id_siswa, $semester_aktif, $id_tahun_ajaran_aktif);
mysqli_stmt_execute($query_rapor_status);
$result_rapor = mysqli_stmt_get_result($query_rapor_status);
if ($rapor_data = mysqli_fetch_assoc($result_rapor)) {
    $rapor_final = ($rapor_data['status'] == 'Final');
    $data_kehadiran['sakit'] = $rapor_data['sakit'] ?? 0;
    $data_kehadiran['izin'] = $rapor_data['izin'] ?? 0;
    $data_kehadiran['tanpa_keterangan'] = $rapor_data['tanpa_keterangan'] ?? 0;
    if(!empty($rapor_data['catatan_wali_kelas'])) {
        $catatan_wali = htmlspecialchars($rapor_data['catatan_wali_kelas']);
    }
    $id_rapor_siswa = $rapor_data['id_rapor'];
}
mysqli_stmt_close($query_rapor_status);

// Ambil 5 nilai sumatif terakhir siswa
$nilai_terakhir = [];
$query_nilai = mysqli_prepare($koneksi,
    "SELECT p.nama_penilaian, p.tanggal_penilaian, mp.nama_mapel, pdn.nilai
     FROM penilaian_detail_nilai pdn
     JOIN penilaian p ON pdn.id_penilaian = p.id_penilaian
     JOIN mata_pelajaran mp ON p.id_mapel = mp.id_mapel
     WHERE pdn.id_siswa = ? AND p.jenis_penilaian = 'Sumatif' AND p.semester = ?
     ORDER BY p.tanggal_penilaian DESC, p.id_penilaian DESC
     LIMIT 5");
mysqli_stmt_bind_param($query_nilai, "ii", $id_siswa, $semester_aktif);
mysqli_stmt_execute($query_nilai);
$result_nilai = mysqli_stmt_get_result($query_nilai);
while ($row = mysqli_fetch_assoc($result_nilai)) {
    $nilai_terakhir[] = $row;
}
mysqli_stmt_close($query_nilai);

// Ambil data ekstrakurikuler
$ekskul_siswa = [];
if ($id_rapor_siswa) {
    $query_ekskul = mysqli_prepare($koneksi,
        "SELECT nama_ekskul, keterangan FROM rapor_detail_ekskul WHERE id_rapor = ? ORDER BY nama_ekskul ASC");
    mysqli_stmt_bind_param($query_ekskul, "i", $id_rapor_siswa);
    mysqli_stmt_execute($query_ekskul);
    $result_ekskul = mysqli_stmt_get_result($query_ekskul);
    while($row = mysqli_fetch_assoc($result_ekskul)){
        $ekskul_siswa[] = $row;
    }
    mysqli_stmt_close($query_ekskul);
}
?>

<!-- =================================================================================
     2. TAMPILAN MODERN (TEAL THEME)
================================================================================== -->
<style>
    /* Base Styling */
    .student-dashboard {
        font-family: 'Poppins', sans-serif;
        background-color: #f0fdfa; /* Light Teal Background */
        min-height: 100vh;
        padding-bottom: 3rem;
        color: #134e4a; /* Dark Teal Text */
    }

    /* 1. HERO PROFILE - TEAL GRADIENT */
    .hero-profile-teal {
        background: linear-gradient(135deg, #14b8a6 0%, #0d9488 100%); /* Teal 500 to 600 */
        border-radius: 24px;
        padding: 2.5rem 2rem;
        color: white;
        position: relative;
        overflow: hidden;
        box-shadow: 0 10px 25px -5px rgba(20, 184, 166, 0.5);
        margin-bottom: 2rem;
    }
    .hero-profile-teal::before {
        content: ''; position: absolute; top: -50px; right: -50px;
        width: 300px; height: 300px;
        background: radial-gradient(circle, rgba(255,255,255,0.15) 0%, transparent 70%);
        border-radius: 50%;
    }
    .hero-profile-teal::after {
        content: ''; position: absolute; bottom: -30px; left: 50px;
        width: 150px; height: 150px;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
    }
    .profile-img-box {
        width: 85px; height: 85px;
        border-radius: 50%;
        border: 3px solid rgba(255,255,255,0.5);
        overflow: hidden;
        background: white;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .profile-img-box img { width: 100%; height: 100%; object-fit: cover; }
    
    .badge-teal {
        background: rgba(255,255,255,0.25);
        backdrop-filter: blur(4px);
        padding: 6px 16px;
        border-radius: 30px;
        font-size: 0.85rem;
        font-weight: 500;
        border: 1px solid rgba(255,255,255,0.4);
    }

    /* 2. MODERN CARDS */
    .modern-card {
        background: white;
        border-radius: 20px;
        border: 1px solid #ccfbf1; /* Very Light Teal Border */
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -1px rgba(0, 0, 0, 0.02);
        height: 100%;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
    }
    .modern-card:hover { 
        transform: translateY(-5px); 
        box-shadow: 0 10px 20px -5px rgba(20, 184, 166, 0.15);
    }
    .card-header-teal {
        background: transparent;
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid #f0fdfa;
        font-weight: 700;
        font-size: 1.1rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #0f766e;
    }
    .card-body-clean { padding: 1.5rem; }

    /* 3. RAPOR STATUS CARD */
    .card-rapor-ready {
        background: linear-gradient(135deg, #2dd4bf 0%, #0d9488 100%); /* Bright Teal */
        color: white; border: none;
    }
    .card-rapor-pending {
        background: linear-gradient(135deg, #fb923c 0%, #ea580c 100%); /* Orange for pending */
        color: white; border: none;
    }
    .rapor-icon-box {
        font-size: 3.5rem; margin-bottom: 1rem;
        opacity: 0.9;
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
    }
    .btn-rapor-teal {
        background: white; color: #0d9488; font-weight: 700;
        border: none; padding: 12px 30px; border-radius: 30px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        transition: all 0.3s;
    }
    .btn-rapor-teal:hover { transform: scale(1.05); box-shadow: 0 6px 15px rgba(0,0,0,0.2); color: #0f766e; }

    /* 4. ATTENDANCE GRID */
    .attendance-grid {
        display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;
    }
    .att-box {
        text-align: center; padding: 1.2rem 0.5rem;
        border-radius: 16px; 
        border: 1px solid transparent;
    }
    .att-val { font-size: 1.8rem; font-weight: 800; line-height: 1; margin-bottom: 5px; }
    .att-lbl { font-size: 0.75rem; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px; }
    
    .att-sakit { background: #fef2f2; color: #ef4444; border-color: #fee2e2; }
    .att-izin { background: #fff7ed; color: #f97316; border-color: #ffedd5; }
    .att-alpha { background: #f1f5f9; color: #64748b; border-color: #e2e8f0; }

    /* 5. NILAI LIST - TEAL ACCENTS */
    .grade-list { list-style: none; padding: 0; margin: 0; }
    .grade-item {
        display: flex; align-items: center; justify-content: space-between;
        padding: 1rem 1.25rem; margin-bottom: 0.75rem;
        background: #fff; border-radius: 16px;
        border: 1px solid #e0e7ff;
        transition: background 0.2s;
    }
    .grade-item:hover { background: #f0fdfa; border-color: #ccfbf1; }
    .grade-icon {
        width: 48px; height: 48px; border-radius: 14px;
        background: #e0f2f1; color: #009688; /* Material Teal */
        display: flex; align-items: center; justify-content: center;
        font-size: 1.3rem; margin-right: 1rem;
    }
    .grade-score {
        font-size: 1.3rem; font-weight: 800; color: #0f766e;
        background: #ccfbf1; padding: 6px 14px; border-radius: 10px;
    }
    .btn-outline-teal {
        color: #0d9488; border: 2px solid #0d9488;
        font-weight: 600; border-radius: 50px;
        padding: 8px 24px;
    }
    .btn-outline-teal:hover { background: #0d9488; color: white; }

    /* 6. EXTRAS */
    .note-box-teal {
        background: #fffbeb; border-left: 5px solid #f59e0b;
        padding: 1.5rem; border-radius: 0 12px 12px 0;
        font-style: italic; color: #4b5563; position: relative;
        box-shadow: 0 2px 5px rgba(0,0,0,0.02);
    }
    .ekskul-badge-teal {
        display: inline-block; padding: 8px 18px;
        background: #ccfbf1; color: #0f766e;
        border-radius: 20px; font-weight: 700;
        margin-right: 8px; margin-bottom: 8px; font-size: 0.85rem;
        border: 1px solid #99f6e4;
    }
</style>

<div class="student-dashboard container-fluid px-4 pt-4">
    
    <!-- 1. HERO PROFILE (TEAL) -->
    <div class="hero-profile-teal">
        <div class="row align-items-center position-relative" style="z-index: 2;">
            <div class="col-lg-8 col-md-7 d-flex align-items-center">
                <div class="profile-img-box me-4 flex-shrink-0">
                    <img src="<?php echo htmlspecialchars($foto_profil_siswa); ?>" alt="Profil">
                </div>
                <div>
                    <h2 class="mb-1 fw-bold">Halo, <?php echo htmlspecialchars($nama_siswa); ?>! 👋</h2>
                    <div class="d-flex flex-wrap gap-2 mt-3">
                        <span class="badge-teal"><i class="bi bi-mortarboard-fill me-1"></i> Kelas <?php echo htmlspecialchars($siswa_detail['nama_kelas']); ?></span>
                        <span class="badge-teal"><i class="bi bi-upc-scan me-1"></i> NISN: <?php echo htmlspecialchars($siswa_detail['nisn']); ?></span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-5 text-md-end mt-4 mt-md-0">
                <div class="p-3 rounded-4 text-center text-md-end" style="background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.2);">
                    <small class="text-uppercase d-block mb-1 opacity-90 fw-bold letter-spacing-1">Tahun Ajaran Aktif</small>
                    <h5 class="mb-0 fw-bold fs-4"><?php echo $nama_tahun_ajaran_aktif; ?></h5>
                    <span class="badge bg-white text-teal mt-2 fw-bold" style="color: #0d9488;">Semester <?php echo $semester_text; ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- 2. STATUS ROW -->
    <div class="row g-4 mb-4">
        <!-- Status Rapor -->
        <div class="col-lg-6">
            <div class="modern-card <?php echo $rapor_final ? 'card-rapor-ready' : 'card-rapor-pending'; ?> border-0">
                <div class="card-body-clean d-flex flex-column align-items-center justify-content-center text-center py-5 h-100">
                    <?php if($rapor_final): ?>
                        <i class="bi bi-file-earmark-check-fill rapor-icon-box"></i>
                        <h3 class="fw-bold mb-2">Rapor Tersedia!</h3>
                        <p class="mb-4 opacity-90 px-3">Hasil belajar semester ini sudah difinalisasi. Kamu hebat!</p>
                        <a href="rapor_pdf.php?id_siswa=<?php echo $id_siswa; ?>" target="_blank" class="btn btn-rapor-teal">
                            <i class="bi bi-download me-2"></i>Download Rapor
                        </a>
                    <?php else: ?>
                        <i class="bi bi-hourglass-split rapor-icon-box"></i>
                        <h3 class="fw-bold mb-2">Rapor Diproses</h3>
                        <p class="mb-0 opacity-90 px-3">Wali kelas sedang merekap nilaimu.</p>
                        <small class="mt-2 d-block opacity-75">Cek lagi nanti ya!</small>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Statistik Kehadiran -->
        <div class="col-lg-6">
            <div class="modern-card">
                <div class="card-header-teal">
                    <span><i class="bi bi-calendar-check me-2"></i>Rekap Kehadiran</span>
                    <span class="badge bg-light text-dark border">Semester Ini</span>
                </div>
                <div class="card-body-clean">
                    <div class="attendance-grid">
                        <div class="att-box att-sakit">
                            <div class="att-val"><?php echo $data_kehadiran['sakit']; ?></div>
                            <div class="att-lbl">Sakit</div>
                        </div>
                        <div class="att-box att-izin">
                            <div class="att-val"><?php echo $data_kehadiran['izin']; ?></div>
                            <div class="att-lbl">Izin</div>
                        </div>
                        <div class="att-box att-alpha">
                            <div class="att-val"><?php echo $data_kehadiran['tanpa_keterangan']; ?></div>
                            <div class="att-lbl">Alpha</div>
                        </div>
                    </div>
                    
                    <div class="mt-4 text-center">
                        <?php 
                        $total_absen = array_sum($data_kehadiran);
                        if ($total_absen == 0) {
                            echo '<div class="alert alert-success border-0 d-inline-block mb-0 py-2 px-4 fw-bold"><i class="bi bi-award-fill me-2"></i> Rajin Sekali! Kehadiran Sempurna.</div>';
                        } else {
                            echo '<span class="text-muted small">Total ketidakhadiran: <strong>'.$total_absen.' hari</strong></span>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 3. CONTENT ROW -->
    <div class="row g-4">
        
        <!-- Kolom Kiri: Nilai Terbaru -->
        <div class="col-lg-7">
            <div class="modern-card">
                <div class="card-header-teal">
                    <span><i class="bi bi-graph-up-arrow me-2"></i>Nilai Sumatif Terbaru</span>
                    <a href="siswa_lihat_nilai.php" class="btn btn-sm btn-outline-teal" style="border-width: 1px; font-size: 0.8rem;">Lihat Semua</a>
                </div>
                <div class="card-body-clean bg-light bg-opacity-25">
                    <?php if (!empty($nilai_terakhir)): ?>
                        <ul class="grade-list">
                            <?php foreach ($nilai_terakhir as $nilai): ?>
                                <li class="grade-item">
                                    <div class="d-flex align-items-center">
                                        <div class="grade-icon shadow-sm">
                                            <i class="bi bi-journal-bookmark-fill"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-1 fw-bold text-dark" style="font-size: 1rem;"><?php echo htmlspecialchars($nilai['nama_mapel']); ?></h6>
                                            <small class="text-muted d-block text-truncate" style="max-width: 220px;">
                                                <?php echo htmlspecialchars($nilai['nama_penilaian']); ?>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="text-end ms-2">
                                        <div class="grade-score"><?php echo $nilai['nilai']; ?></div>
                                        <small class="text-muted fw-medium" style="font-size: 0.7rem;">
                                            <?php echo date('d/m', strtotime($nilai['tanggal_penilaian'])); ?>
                                        </small>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="text-center mt-2">
                            <a href="siswa_lihat_nilai.php" class="btn btn-link text-decoration-none fw-bold text-teal" style="color: #0d9488;">Lihat Selengkapnya <i class="bi bi-arrow-right"></i></a>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <div class="mb-3 opacity-50 text-teal" style="font-size: 4rem;"><i class="bi bi-inbox"></i></div>
                            <h6 class="fw-bold text-secondary">Belum Ada Nilai</h6>
                            <p class="text-muted small mb-0">Bapak/Ibu Guru belum menginput nilai sumatif.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Kolom Kanan: Catatan & Ekskul -->
        <div class="col-lg-5">
            <div class="d-flex flex-column gap-4">
                
                <!-- Catatan Wali Kelas -->
                <div class="modern-card">
                    <div class="card-header-teal">
                        <span><i class="bi bi-chat-quote-fill me-2 text-warning"></i>Catatan Wali Kelas</span>
                    </div>
                    <div class="card-body-clean">
                        <div class="note-box-teal">
                            <p class="mb-0 lh-base fw-medium">
                                <?php echo nl2br($catatan_wali); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Ekstrakurikuler -->
                <div class="modern-card">
                    <div class="card-header-teal">
                        <span><i class="bi bi-trophy-fill me-2 text-danger"></i>Ekstrakurikuler</span>
                    </div>
                    <div class="card-body-clean">
                        <?php if (!empty($ekskul_siswa)): ?>
                            <div class="d-flex flex-wrap">
                                <?php foreach ($ekskul_siswa as $ekskul): ?>
                                    <div class="w-100 mb-3 border-bottom pb-2 last:border-0">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="ekskul-badge-teal shadow-sm">
                                                <?php echo htmlspecialchars($ekskul['nama_ekskul']); ?>
                                            </span>
                                        </div>
                                        <small class="text-muted ps-1 d-block">
                                            <i class="bi bi-info-circle me-1 text-teal" style="color: #0d9488;"></i> 
                                            <?php echo htmlspecialchars($ekskul['keterangan']); ?>
                                        </small>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <small class="text-muted fst-italic">Tidak mengikuti ekstrakurikuler semester ini.</small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>