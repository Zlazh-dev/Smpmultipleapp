<?php
include 'header.php';
include 'koneksi.php';

// ==========================================================
// 1. VALIDASI AKSES & INISIALISASI
// ==========================================================
if ($_SESSION['role'] != 'admin') {
    echo "<script>Swal.fire({icon: 'error', title: 'Akses Ditolak'}).then(() => window.location = 'dashboard.php');</script>";
    include 'footer.php';
    exit;
}

// Ambil Tahun Ajaran Aktif
$q_ta = mysqli_query($koneksi, "SELECT id_tahun_ajaran, tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
$ta_aktif = mysqli_fetch_assoc($q_ta);
$id_tahun_ajaran_aktif = $ta_aktif['id_tahun_ajaran'] ?? 0;
$tahun_ajaran_label = $ta_aktif['tahun_ajaran'] ?? '-';

// Ambil Semester & KKM
$q_smt = mysqli_query($koneksi, "SELECT nilai_pengaturan FROM pengaturan WHERE nama_pengaturan = 'semester_aktif' LIMIT 1");
$semester_aktif = mysqli_fetch_assoc($q_smt)['nilai_pengaturan'] ?? 1;
// Ambil KKM (dibutuhkan untuk tampilan di modal)
$q_kkm = mysqli_query($koneksi, "SELECT nilai_pengaturan FROM pengaturan WHERE nama_pengaturan = 'kkm' LIMIT 1");
$kkm = mysqli_fetch_assoc($q_kkm)['nilai_pengaturan'] ?? 75;


// --- FUNGSI BARU UNTUK MENGATASI MAPEL AGAMA ---
function get_relevant_agama($nama_mapel) {
    if (stripos($nama_mapel, 'islam') !== false) return 'Islam';
    if (stripos($nama_mapel, 'kristen') !== false) return 'Kristen';
    if (stripos($nama_mapel, 'katolik') !== false) return 'Katolik';
    if (stripos($nama_mapel, 'hindu') !== false) return 'Hindu';
    if (stripos($nama_mapel, 'budha') !== false) return 'Budha';
    if (stripos($nama_mapel, 'konghucu') !== false) return 'Konghucu';
    return null; 
}

/**
 * Menghitung jumlah siswa aktif yang relevan dengan mapel di kelas tertentu.
 */
function get_relevant_siswa_count($koneksi, $id_kelas, $id_mapel) {
    global $id_tahun_ajaran_aktif; 

    // Ambil nama mapel
    $q_mapel = mysqli_query($koneksi, "SELECT nama_mapel FROM mata_pelajaran WHERE id_mapel = $id_mapel LIMIT 1");
    $nama_mapel = mysqli_fetch_assoc($q_mapel)['nama_mapel'] ?? '';
    $relevant_agama = get_relevant_agama($nama_mapel);

    $siswa_where = "id_kelas = $id_kelas AND status_siswa = 'Aktif'";

    if ($relevant_agama) {
        // Jika Mapel Agama, filter berdasarkan agama siswa
        $siswa_where .= " AND agama = '" . mysqli_real_escape_string($koneksi, $relevant_agama) . "'";
    }
    
    $q_count = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM siswa WHERE $siswa_where");
    return mysqli_fetch_assoc($q_count)['total'] ?? 0;
}
// --- AKHIR FUNGSI BARU ---


// ==========================================================
// 2. LOGIKA STATISTIK GLOBAL (Dashboard Atas)
// ==========================================================
$labels_mapel = [];
$persen_mapel = [];
$global_total_nilai_terinput = 0;
$global_target_total_nilai = 0;

// Ambil daftar semua mapel untuk statistik chart
$query_semua_mapel = mysqli_query($koneksi, "SELECT id_mapel, nama_mapel FROM mata_pelajaran ORDER BY urutan ASC");

while ($mapel_global = mysqli_fetch_assoc($query_semua_mapel)) {
    $id_mapel_global = $mapel_global['id_mapel'];
    $nama_mapel_global = $mapel_global['nama_mapel'];
    $relevant_agama_global = get_relevant_agama($nama_mapel_global);

    // Dapatkan semua kelas yang mengajar mapel ini di TA aktif
    $q_kelas_ajar = mysqli_query($koneksi, "
        SELECT DISTINCT k.id_kelas
        FROM kelas k
        JOIN guru_mengajar gm ON k.id_kelas = gm.id_kelas
        WHERE gm.id_mapel = $id_mapel_global AND k.id_tahun_ajaran = $id_tahun_ajaran_aktif
    ");
    
    $mapel_target = 0;
    $mapel_realisasi = 0;

    while($kelas_ajar = mysqli_fetch_assoc($q_kelas_ajar)) {
        $id_kelas = $kelas_ajar['id_kelas'];
        
        // A. Hitung Jumlah Asesmen Sumatif di kelas ini
        $q_jml_asesmen = mysqli_query($koneksi, "
            SELECT COUNT(id_penilaian) as jml_asesmen
            FROM penilaian 
            WHERE id_mapel = $id_mapel_global 
              AND id_kelas = $id_kelas
              AND semester = $semester_aktif 
              AND jenis_penilaian = 'Sumatif'
        ");
        $jml_asesmen = mysqli_fetch_assoc($q_jml_asesmen)['jml_asesmen'];

        // B. Hitung Jumlah Siswa yang RELEVAN di kelas ini
        $relevant_siswa_count = get_relevant_siswa_count($koneksi, $id_kelas, $id_mapel_global);
        
        // Target Nilai = Jml Asesmen x Jml Siswa Relevan
        $target_kelas = $jml_asesmen * $relevant_siswa_count;
        $mapel_target += $target_kelas;

        // C. Hitung realisasi (nilai yang sudah masuk) dari siswa yang RELEVAN
        $q_realisasi_kelas_str = "
            SELECT COUNT(pdn.id_detail_nilai) as total 
            FROM penilaian_detail_nilai pdn 
            JOIN penilaian p ON pdn.id_penilaian = p.id_penilaian
            JOIN siswa s ON pdn.id_siswa = s.id_siswa
            WHERE p.id_mapel = $id_mapel_global 
              AND p.id_kelas = $id_kelas 
              AND p.semester = $semester_aktif 
              AND p.jenis_penilaian = 'Sumatif'
              AND s.status_siswa = 'Aktif'
              " . ($relevant_agama_global ? "AND s.agama = '$relevant_agama_global'" : "") . "
        ";
        $q_realisasi_kelas = mysqli_query($koneksi, $q_realisasi_kelas_str);
        $realisasi_kelas = mysqli_fetch_assoc($q_realisasi_kelas)['total'];
        $mapel_realisasi += $realisasi_kelas;
    }

    // Simpan data untuk chart jika ada target
    if ($mapel_target > 0) {
        $persen = round(($mapel_realisasi / $mapel_target) * 100);
        $labels_mapel[] = $mapel_global['nama_mapel'];
        // Batasi persen di 100%
        $persen_mapel[] = min(100, $persen);
        
        $global_target_total_nilai += $mapel_target;
        $global_total_nilai_terinput += $mapel_realisasi;
    }
}

$persentase_global = ($global_target_total_nilai > 0) ? round(($global_total_nilai_terinput / $global_target_total_nilai) * 100) : 0;
// Batasi persen global di 100%
$persentase_global = min(100, $persentase_global);
?>

<style>
    .hero-header {
        background: linear-gradient(120deg, #1e3c72 0%, #2a5298 100%); /* Warna Biru Admin */
        color: white;
        padding: 2.5rem 2rem;
        border-radius: 15px;
        margin-bottom: 2rem;
        position: relative;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .hero-header::after {
        content: '';
        position: absolute;
        top: 0; right: 0; bottom: 0; left: 0;
        background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    }
    .card-kpi {
        border: none;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        transition: transform 0.2s;
        height: 100%;
    }
    .card-kpi:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
    
    /* Accordion Styling */
    .accordion-item {
        border: none;
        margin-bottom: 10px;
        border-radius: 10px !important;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        overflow: hidden;
    }
    .accordion-button {
        background-color: #fff;
        color: #333;
        font-weight: 600;
        border-radius: 10px !important;
    }
    .accordion-button:not(.collapsed) {
        background-color: #e3f2fd;
        color: #0d47a1;
        box-shadow: none;
    }
    .accordion-button:focus {
        box-shadow: none;
        border-color: rgba(0,0,0,.125);
    }
    
    /* Table Styling */
    .table-custom th {
        background-color: #f8f9fa;
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
        color: #6c757d;
    }
    .avatar-initial {
        width: 35px; height: 35px;
        background-color: #e9ecef;
        color: #495057;
        border-radius: 50%;
        display: inline-flex;
        align-items: center; justify-content: center;
        font-weight: bold;
        font-size: 0.8rem;
        margin-right: 10px;
    }
    .progress-thin {
        height: 8px;
        border-radius: 4px;
        background-color: #e9ecef;
    }
</style>

<div class="container-fluid py-4">
    
    <!-- HEADER -->
    <div class="hero-header">
        <div class="row align-items-center position-relative" style="z-index: 2;">
            <div class="col-md-8">
                <h2 class="fw-bold mb-1"><i class="bi bi-bar-chart-line-fill me-2"></i>Dashboard Progres Penilaian</h2>
                <p class="mb-0 opacity-75">
                    Monitoring input nilai Sumatif seluruh kelas. <br>
                    Tahun Ajaran: <strong><?php echo $tahun_ajaran_label; ?></strong> | Semester: <strong><?php echo $semester_aktif; ?></strong>
                </p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <div class="d-inline-block bg-white text-dark p-3 rounded-3 shadow-sm text-start">
                    <small class="text-muted d-block text-uppercase fw-bold" style="font-size: 0.7rem;">Target Global</small>
                    <div class="d-flex align-items-baseline">
                        <h2 class="mb-0 fw-bold text-primary me-2"><?php echo $persentase_global; ?>%</h2>
                        <span class="text-muted">Tercapai</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- KPI CARDS -->
    <div class="row g-4 mb-4">
        <!-- Card Total Input -->
        <div class="col-md-4">
            <div class="card card-kpi">
                <div class="card-body">
                    <h6 class="text-muted text-uppercase small mb-3">Total Nilai Masuk</h6>
                    <div class="d-flex align-items-center">
                        <div class="display-5 fw-bold text-dark"><?php echo number_format($global_total_nilai_terinput); ?></div>
                        <div class="ms-auto text-success bg-success bg-opacity-10 p-3 rounded-circle">
                            <i class="bi bi-database-check fs-3"></i>
                        </div>
                    </div>
                    <div class="progress mt-3" style="height: 6px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $persentase_global; ?>%"></div>
                    </div>
                    <small class="text-muted mt-2 d-block">Dari target <?php echo number_format($global_target_total_nilai); ?> data nilai</small>
                </div>
            </div>
        </div>

        <!-- Card Grafik Mapel -->
        <div class="col-md-8">
            <div class="card card-kpi">
                <div class="card-body">
                    <h6 class="text-muted text-uppercase small mb-2">Sebaran Progres per Mapel</h6>
                    <div style="height: 200px; width: 100%;">
                        <canvas id="chartMapel"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <hr class="my-4 text-muted opacity-25">

    <!-- ACCORDION KELAS -->
    <h5 class="mb-3 fw-bold text-primary"><i class="bi bi-layers-fill me-2"></i>Rincian Progres per Kelas</h5>
    
    <div class="accordion" id="accordionKelas">
    <?php
    // Ambil daftar kelas di tahun ajaran aktif
    $q_kelas = mysqli_query($koneksi, "
        SELECT k.id_kelas, k.nama_kelas, g.nama_guru as wali_kelas
        FROM kelas k
        LEFT JOIN guru g ON k.id_wali_kelas = g.id_guru
        WHERE k.id_tahun_ajaran = $id_tahun_ajaran_aktif 
        ORDER BY k.nama_kelas ASC
    ");

    if (mysqli_num_rows($q_kelas) > 0):
        $count = 0;
        while($kelas = mysqli_fetch_assoc($q_kelas)):
            $id_kelas = $kelas['id_kelas'];
            $count++;
            
            // Hitung siswa aktif di kelas ini (total, bukan yang relevan)
            $q_siswa = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM siswa WHERE id_kelas = $id_kelas AND status_siswa = 'Aktif'");
            $jml_siswa_total = mysqli_fetch_assoc($q_siswa)['jml'];
    ?>
        <div class="accordion-item">
            <h2 class="accordion-header" id="heading<?php echo $id_kelas; ?>">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $id_kelas; ?>">
                    <div class="d-flex w-100 justify-content-between align-items-center me-3">
                        <div>
                            <span class="fw-bold me-2"><?php echo htmlspecialchars($kelas['nama_kelas']); ?></span>
                            <span class="badge bg-light text-secondary border fw-normal">Wali: <?php echo htmlspecialchars($kelas['wali_kelas'] ?? '-'); ?></span>
                        </div>
                        <span class="badge bg-primary rounded-pill"><?php echo $jml_siswa_total; ?> Siswa Aktif</span>
                    </div>
                </button>
            </h2>
            <div id="collapse<?php echo $id_kelas; ?>" class="accordion-collapse collapse" data-bs-parent="#accordionKelas">
                <div class="accordion-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover table-custom align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4" style="width: 5%;">No</th>
                                    <th style="width: 30%;">Mata Pelajaran</th>
                                    <th style="width: 25%;">Guru Pengampu</th>
                                    <th style="width: 20%;">Target & Progres</th>
                                    <th style="width: 15%;">Status Input Nilai</th>
                                    <th class="text-center" style="width: 5%;">Detail</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Ambil Mapel yang DIAJARKAN di kelas ini
                                $q_mapel_ajar = mysqli_query($koneksi, "
                                    SELECT gm.id_mapel, m.nama_mapel, g.nama_guru, g.id_guru
                                    FROM guru_mengajar gm
                                    JOIN mata_pelajaran m ON gm.id_mapel = m.id_mapel
                                    JOIN guru g ON gm.id_guru = g.id_guru
                                    WHERE gm.id_kelas = $id_kelas AND gm.id_tahun_ajaran = $id_tahun_ajaran_aktif
                                    ORDER BY m.urutan ASC
                                ");

                                if (mysqli_num_rows($q_mapel_ajar) > 0) {
                                    $no_mapel = 1;
                                    while($mapel = mysqli_fetch_assoc($q_mapel_ajar)) {
                                        $id_mapel = $mapel['id_mapel'];
                                        $nama_mapel = $mapel['nama_mapel'];
                                        $id_guru = $mapel['id_guru'];

                                        // B. Hitung Jumlah Siswa yang RELEVAN di kelas ini
                                        $relevant_siswa_count = get_relevant_siswa_count($koneksi, $id_kelas, $id_mapel);
                                        $relevant_agama = get_relevant_agama($nama_mapel);
                                        
                                        // A. Hitung Jumlah Asesmen Sumatif di kelas ini
                                        $q_stat = mysqli_query($koneksi, "
                                            SELECT COUNT(id_penilaian) as jml_asesmen 
                                            FROM penilaian 
                                            WHERE id_kelas = $id_kelas AND id_mapel = $id_mapel 
                                            AND semester = $semester_aktif AND jenis_penilaian = 'Sumatif'
                                        ");
                                        $jml_asesmen = mysqli_fetch_assoc($q_stat)['jml_asesmen'];

                                        // Hitung Target Total Nilai (Hanya dari siswa yang relevan)
                                        $target_nilai = $jml_asesmen * $relevant_siswa_count;
                                        
                                        // C. Hitung realisasi (nilai yang sudah masuk) dari siswa yang RELEVAN
                                        $q_nilai_masuk_str = "
                                            SELECT COUNT(pdn.id_detail_nilai) as jml_masuk
                                            FROM penilaian_detail_nilai pdn
                                            JOIN penilaian p ON pdn.id_penilaian = p.id_penilaian
                                            JOIN siswa s ON pdn.id_siswa = s.id_siswa
                                            WHERE p.id_kelas = $id_kelas AND p.id_mapel = $id_mapel 
                                            AND p.semester = $semester_aktif AND p.jenis_penilaian = 'Sumatif'
                                            AND s.status_siswa = 'Aktif'
                                            " . ($relevant_agama ? "AND s.agama = '$relevant_agama'" : "") . "
                                        ";
                                        $q_nilai = mysqli_query($koneksi, $q_nilai_masuk_str);
                                        $jml_masuk = mysqli_fetch_assoc($q_nilai)['jml_masuk'];


                                        $persen = ($target_nilai > 0) ? round(($jml_masuk / $target_nilai) * 100) : 0;
                                        $persen = min(100, $persen); // Batasi di 100%
                                        
                                        // Visual State
                                        $progress_color = 'bg-primary';
                                        $status_badge_class = 'bg-primary';
                                        $status_text = 'Proses';

                                        if ($jml_asesmen == 0) {
                                            $progress_color = 'bg-danger';
                                            $status_badge_class = 'bg-danger';
                                            $status_text = 'Belum Ada Asesmen';
                                            $persen = 0;
                                        } elseif ($relevant_siswa_count == 0) {
                                            $progress_color = 'bg-secondary';
                                            $status_badge_class = 'bg-secondary';
                                            $status_text = 'Tidak Ada Siswa Relevan';
                                            $persen = 100; // Jika tidak ada siswa, dianggap tuntas
                                        } elseif ($persen >= 100) {
                                            $progress_color = 'bg-success';
                                            $status_badge_class = 'bg-success';
                                            $status_text = 'Selesai';
                                        } elseif ($persen == 0) {
                                            $progress_color = 'bg-warning text-dark';
                                            $status_badge_class = 'bg-warning text-dark';
                                            $status_text = 'Belum Input Nilai';
                                        }
                                ?>
                                <tr>
                                    <td class="ps-4 text-muted"><?php echo $no_mapel++; ?></td>
                                    <td>
                                        <span class="fw-bold text-dark"><?php echo htmlspecialchars($mapel['nama_mapel']); ?></span>
                                        <div class="small text-muted mt-1"><i class="bi bi-people me-1"></i>Target: <?php echo $relevant_siswa_count; ?> Siswa 
                                            <?php echo $relevant_agama ? "($relevant_agama)" : ""; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-initial"><?php echo strtoupper(substr($mapel['nama_guru'], 0, 2)); ?></div>
                                            <span class="text-secondary"><?php echo htmlspecialchars($mapel['nama_guru']); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-between mb-1">
                                            <span class="fw-bold"><?php echo $persen; ?>%</span>
                                            <small class="text-muted">Target: <?php echo $jml_asesmen; ?> Asesmen</small>
                                        </div>
                                        <div class="progress progress-thin">
                                            <div class="progress-bar <?php echo $progress_color; ?>" role="progressbar" style="width: <?php echo $persen; ?>%"></div>
                                        </div>
                                        <small class="text-muted d-block mt-1" style="font-size: 0.7rem;">
                                            <?php echo number_format($jml_masuk); ?> / <?php echo number_format($target_nilai); ?> Nilai Masuk
                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $status_badge_class; ?>"><?php echo $status_text; ?></span>
                                    </td>
                                    <td class="text-center">
                                        <!-- Tombol MODAL untuk Admin -->
                                        <?php if($jml_asesmen > 0 && $relevant_siswa_count > 0): ?>
                                        <button class="btn btn-sm btn-outline-primary btn-lihat-detail" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#detailNilaiModalAdmin"
                                                data-id-mapel="<?php echo $id_mapel; ?>"
                                                data-id-kelas="<?php echo $id_kelas; ?>"
                                                data-nama-mapel="<?php echo htmlspecialchars($mapel['nama_mapel']); ?>"
                                                data-nama-guru="<?php echo htmlspecialchars($mapel['nama_guru']); ?>">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <?php else: ?>
                                         <button class="btn btn-sm btn-light text-muted" disabled><i class="bi bi-slash-circle"></i></button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php 
                                    } // End While Mapel
                                } else {
                                    echo "<tr><td colspan='6' class='text-center py-4 text-muted'>Belum ada plotting guru mata pelajaran di kelas ini.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php
        endwhile;
    else:
    ?>
        <div class="alert alert-info text-center">Data kelas tidak ditemukan untuk Tahun Ajaran aktif.</div>
    <?php endif; ?>
    </div>
</div>

<!-- ====================================================== -->
<!-- MODAL DETAIL NILAI UNTUK ADMIN -->
<!-- Menggunakan AJAX ke walikelas_proses_rapor.php untuk ambil data -->
<!-- ====================================================== -->
<div class="modal fade" id="detailNilaiModalAdmin" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <div>
                    <h5 class="modal-title" id="modalLabelAdmin">Rincian Perkiraan Nilai Rapor</h5>
                    <small id="modalSubTitleAdmin" class="opacity-75"></small>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body bg-light">
                <!-- Loading Spinner -->
                <div id="loadingStateAdmin" class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2 text-muted">Sedang mengkalkulasi nilai...</p>
                </div>

                <!-- Table Content -->
                <div id="contentTableAdmin" class="d-none">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover mb-0">
                                    <thead class="table-dark">
                                        <tr>
                                            <th class="ps-4" width="5%">No</th>
                                            <th width="30%">Nama Siswa</th>
                                            <th width="15%">NISN</th>
                                            <th class="text-center" width="15%">Jml Asesmen Masuk</th>
                                            <th class="text-center" width="15%">Perkiraan Nilai Akhir</th>
                                            <th class="text-center" width="20%">Status (KKM: <?php echo $kkm; ?>)</th>
                                        </tr>
                                    </thead>
                                    <tbody id="modalTableBodyAdmin">
                                        <!-- Data will be injected here via JS -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="alert alert-info mt-3 mb-0 d-flex align-items-center">
                        <i class="bi bi-info-circle-fill fs-4 me-3"></i>
                        <div>
                            <strong>Catatan Admin:</strong> Nilai ini dihitung berdasarkan rata-rata tertimbang Sumatif. Daftar ini hanya menampilkan siswa aktif yang relevan (termasuk filter agama).
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // --- LOGIKA CHART (Tidak Berubah) ---
    const ctx = document.getElementById('chartMapel');
    if (ctx) {
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels_mapel); ?>,
                datasets: [{
                    label: 'Persentase Nilai Masuk',
                    data: <?php echo json_encode($persen_mapel); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: { callback: function(value){return value + "%"} }
                    },
                    x: {
                        ticks: { autoSkip: false, maxRotation: 45, minRotation: 45, font: {size: 10} }
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) { return context.raw + '% Terinput'; }
                        }
                    }
                }
            }
        });
    }

    // --- LOGIKA MODAL DETAIL NILAI ADMIN (BARU) ---
    const detailModal = document.getElementById('detailNilaiModalAdmin');
    const loadingState = document.getElementById('loadingStateAdmin');
    const contentTable = document.getElementById('contentTableAdmin');
    const tableBody = document.getElementById('modalTableBodyAdmin');
    const modalSubTitle = document.getElementById('modalSubTitleAdmin');
    
    // Gunakan event delegation pada tombol lihat detail
    document.querySelectorAll('.btn-lihat-detail').forEach(button => {
        button.addEventListener('click', function(event) {
            const idMapel = this.getAttribute('data-id-mapel');
            const idKelas = this.getAttribute('data-id-kelas');
            const namaMapel = this.getAttribute('data-nama-mapel');
            const namaGuru = this.getAttribute('data-nama-guru');

            // Kita perlu simulasi variabel sesi $id_kelas di walikelas_proses_rapor.php
            // Dengan mengirim id_kelas melalui body, kita bisa modifikasi walikelas_proses_rapor.php 
            // agar bisa membaca id_kelas dari POST jika ada, dan dari SESSION jika tidak ada.
            // Namun, untuk meminimalisir perubahan di file lain, kita akan gunakan file proxy AJAX khusus admin.
            
            // Karena tidak ada file proxy, kita harus mengirim ID_KELAS & ID_MAPEL ke AJAX handler yang BISA Admin akses.
            // Kita akan buat request ke walikelas_proses_rapor.php dan TIDAK akan menggunakan id_guru/id_kelas dari sesi admin.

            modalSubTitle.textContent = `${namaMapel} (Kelas ID: ${idKelas}) - Guru: ${namaGuru}`;
            
            loadingState.classList.remove('d-none');
            contentTable.classList.add('d-none');
            tableBody.innerHTML = '';

            const formData = new FormData();
            formData.append('ajax_action', 'get_nilai_mapel');
            formData.append('id_mapel', idMapel);
            // Kunci: Kirim ID Kelas yang spesifik yang sedang dilihat oleh Admin, 
            // menimpa logika pengambilan ID Kelas dari sesi yang ada di walikelas_proses_rapor.php
            // (Asumsi: Anda akan melakukan perubahan kecil di walikelas_proses_rapor.php agar menerima POST ID Kelas untuk Admin)
            formData.append('admin_id_kelas', idKelas); 

            // Catatan: Karena walikelas_proses_rapor.php melakukan validasi role, Admin tidak bisa akses.
            // Solusi Paling Cepat: Buat AJAX handler di file ini atau file baru yang tidak ada validasi sesi.
            // Kita akan buat handler di file ini saja.
            
            // Karena kita tidak bisa mengubah header/PHP flow di sini, kita akan tetap menggunakan file 
            // walikelas_proses_rapor.php DENGAN MODIFIKASI:

            // 1. Kirim ID Mapel & ID Kelas yang ditargetkan:
            const dataToFetch = new URLSearchParams();
            dataToFetch.append('ajax_action', 'get_nilai_mapel');
            dataToFetch.append('id_mapel', idMapel);
            dataToFetch.append('admin_view_id_kelas', idKelas);
            // Tambahkan flag admin_access agar walikelas_proses_rapor.php tahu ini dari Admin
            dataToFetch.append('admin_access', 'true'); 

            fetch('walikelas_proses_rapor.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: dataToFetch
            })
            .then(response => {
                // Walikelas_proses_rapor.php mungkin mengembalikan redirect atau JSON error
                if (response.headers.get('content-type') && response.headers.get('content-type').includes('application/json')) {
                    return response.json();
                } else {
                    // Jika bukan JSON (misal: redirect ke login), tangani sebagai error generik.
                    throw new Error("Respon tidak valid dari server (bukan JSON).");
                }
            })
            .then(data => {
                loadingState.classList.add('d-none');
                contentTable.classList.remove('d-none');
                tableBody.innerHTML = '';

                if (data && data.error) {
                    // Tangani error dari walikelas_proses_rapor.php (misal: Akses Ditolak)
                    tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">Error Akses: ${data.error}. Pastikan ID Kelas terkirim dengan benar.</td></tr>`;
                    return;
                }

                if (!data || data.length === 0) {
                    tableBody.innerHTML = '<tr><td colspan="6" class="text-center py-4">Tidak ada data siswa aktif yang relevan.</td></tr>';
                    return;
                }

                let html = '';
                // KKM dari PHP untuk JS
                const kkm_js = <?php echo $kkm; ?>; 

                data.forEach((siswa, index) => {
                    let badgeClass = 'bg-secondary';
                    let nilaiDisplay = siswa.nilai_akhir;
                    let statusIcon = '';
                    let statusText = siswa.status;

                    if (siswa.nilai_akhir === '-' || siswa.nilai_akhir === 0) {
                        nilaiDisplay = '<span class="text-muted fst-italic">Belum ada</span>';
                        badgeClass = 'bg-light text-dark border';
                        statusText = 'Belum Dinilai';
                    } else if (siswa.status === 'Tuntas') {
                        badgeClass = 'bg-success';
                        statusIcon = '<i class="bi bi-check-lg me-1"></i> ';
                    } else {
                        badgeClass = 'bg-danger';
                        statusIcon = '<i class="bi bi-x-lg me-1"></i> ';
                    }

                    html += `
                        <tr>
                            <td class="ps-4">${index + 1}</td>
                            <td class="fw-bold">${siswa.nama}</td>
                            <td>${siswa.nisn}</td>
                            <td class="text-center">${siswa.jml_asesmen_diikuti}</td>
                            <td class="text-center fw-bold fs-5">${nilaiDisplay}</td>
                            <td class="text-center">
                                <span class="badge ${badgeClass}">${statusIcon}${statusText}</span>
                            </td>
                        </tr>
                    `;
                });
                tableBody.innerHTML = html;
            })
            .catch(error => {
                console.error('Fetch Error:', error);
                loadingState.classList.add('d-none');
                contentTable.classList.remove('d-none');
                tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-danger py-4">Gagal memuat data. Periksa konsol untuk error.</td></tr>';
            });
        });
    });
});
</script>

<?php include 'footer.php'; ?>