<?php
session_start();
include 'koneksi.php';
require_once 'libs/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;

// =======================================================================
// 1. VALIDASI & PENGAMBILAN DATA
// =======================================================================
$id_siswa = isset($_GET['id_siswa']) ? (int)$_GET['id_siswa'] : 0;
if ($id_siswa == 0) die("Error: ID Siswa tidak valid.");

// [UPDATE] Join ke tabel kelas agar nama_kelas muncul
$q_siswa = mysqli_prepare($koneksi, "
    SELECT s.*, k.nama_kelas 
    FROM siswa s 
    LEFT JOIN kelas k ON s.id_kelas = k.id_kelas 
    WHERE s.id_siswa = ?
");
mysqli_stmt_bind_param($q_siswa, "i", $id_siswa);
mysqli_stmt_execute($q_siswa);
$result_siswa = mysqli_stmt_get_result($q_siswa);

if(mysqli_num_rows($result_siswa) == 0) die("Error: Data siswa tidak ditemukan.");
$siswa = mysqli_fetch_assoc($result_siswa);

// Ambil data sekolah
$q_sekolah = mysqli_query($koneksi, "SELECT nama_sekolah, nama_kepsek, nip_kepsek, jabatan_kepsek, kecamatan, kabupaten_kota FROM sekolah WHERE id_sekolah = 1");
$sekolah = mysqli_fetch_assoc($q_sekolah);

// [BARU] Ambil Pengaturan Ukuran Kertas
$pengaturan = [];
$q_set = mysqli_query($koneksi, "SELECT * FROM pengaturan");
while($r = mysqli_fetch_assoc($q_set)) {
    $pengaturan[$r['nama_pengaturan']] = $r['nilai_pengaturan'];
}
$ukuran_kertas = $pengaturan['rapor_ukuran_kertas'] ?? 'A4';

// =======================================================================
// 2. FUNGSI BANTUAN
// =======================================================================
function tanggal_indo($tanggal) {
    if(empty($tanggal) || $tanggal == '0000-00-00') return "-";
    $bulan = array (1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember');
    $pecahkan = explode('-', $tanggal);
    if(count($pecahkan) != 3) return $tanggal;
    return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}

// Helper untuk foto lokal
function get_img_base64_local($path) {
    if (!empty($path) && file_exists($path)) {
        $type = pathinfo($path, PATHINFO_EXTENSION);
        $data = file_get_contents($path);
        return 'data:image/' . $type . ';base64,' . base64_encode($data);
    }
    return '';
}

// =======================================================================
// 3. PERSIAPAN FOTO
// =======================================================================
$foto_html = '';
if (!empty($siswa['foto_siswa'])) {
    $path_foto = 'uploads/foto_siswa/' . $siswa['foto_siswa'];
    $foto_base64 = get_img_base64_local($path_foto);
    if ($foto_base64) {
        $foto_html = '<img src="' . $foto_base64 . '" style="width: 100%; height: 100%; object-fit: cover;">';
    }
}
// Placeholder foto kosong
if (empty($foto_html)) {
    $foto_html = '<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; font-size: 8pt; color: #ccc; background-color: #f9f9f9;">FOTO<br>3 x 4</div>';
}

// =======================================================================
// 4. GENERATE HTML
// =======================================================================
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Identitas Siswa - <?php echo htmlspecialchars($siswa['nama_lengkap']); ?></title>
    <style>
        /* Margin akan disesuaikan otomatis oleh DomPDF, margin body cukup minimal */
        @page { margin: 2cm 2cm; }
        body { font-family: 'Times New Roman', Times, serif; font-size: 11pt; color: #000; }
        
        /* Style Tabel Identitas yang Rapi */
        .biodata-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .biodata-table td { padding: 6px 5px; vertical-align: top; border-bottom: 1px solid #e0e0e0; }
        .biodata-table tr:last-child td { border-bottom: none; }
        .label-text { color: #444; }
        .value-text { color: #000; font-weight: 500; }
        
        /* Style Tanda Tangan */
        .signature-table { width: 100%; margin-top: 40px; border: none; page-break-inside: avoid; }
        .signature-table td { vertical-align: top; border: none; }
    </style>
</head>
<body>

    <!-- Wrapper agar aman dijilid -->
    <div style="padding: 0 10px;">

        <!-- JUDUL -->
        <div style="text-align: center; font-weight: bold; font-size: 16pt; margin-bottom: 30px; text-transform: uppercase; border-bottom: 3px double #333; padding-bottom: 10px;">
            IDENTITAS PESERTA DIDIK
        </div>

        <!-- TABEL BIODATA -->
        <table class="biodata-table">
            <tr>
                <td style="width: 5%;">1.</td>
                <td class="label-text" style="width: 30%;">Nama Lengkap Peserta Didik</td>
                <td style="width: 2%;">:</td>
                <td class="value-text" style="width: 63%; font-size: 12pt;"><b><?php echo strtoupper(htmlspecialchars($siswa['nama_lengkap'])); ?></b></td>
            </tr>
            <tr>
                <td>2.</td>
                <td class="label-text">NIS / NISN</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars(($siswa['nis']??'-') . ' / ' . ($siswa['nisn']??'-')); ?></td>
            </tr>
            <tr>
                <td>3.</td>
                <td class="label-text">Tempat, Tanggal Lahir</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['tempat_lahir']) . ', ' . tanggal_indo($siswa['tanggal_lahir']); ?></td>
            </tr>
            <tr>
                <td>4.</td>
                <td class="label-text">Jenis Kelamin</td>
                <td>:</td>
                <td class="value-text"><?php echo ($siswa['jenis_kelamin'] == 'L') ? 'Laki-laki' : 'Perempuan'; ?></td>
            </tr>
            <tr>
                <td>5.</td>
                <td class="label-text">Agama</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['agama']); ?></td>
            </tr>
            <tr>
                <td>6.</td>
                <td class="label-text">Status dalam Keluarga</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['status_dalam_keluarga']); ?></td>
            </tr>
            <tr>
                <td>7.</td>
                <td class="label-text">Anak ke</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['anak_ke']); ?></td>
            </tr>
            <tr>
                <td>8.</td>
                <td class="label-text">Alamat Peserta Didik</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['alamat']); ?></td>
            </tr>
            <tr>
                <td>9.</td>
                <td class="label-text">Nomor Telepon/HP</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['telepon_siswa']); ?></td>
            </tr>
            <tr>
                <td>10.</td>
                <td class="label-text">Sekolah Asal</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['sekolah_asal']); ?></td>
            </tr>

            <!-- DITERIMA DI SEKOLAH -->
            <tr style="background-color: #fafafa;">
                <td>11.</td>
                <td colspan="3" style="font-weight: bold;">Diterima di sekolah ini</td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">Di kelas</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['nama_kelas'] ?? '-'); ?></td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">Pada tanggal</td>
                <td>:</td>
                <td class="value-text"><?php echo !empty($siswa['diterima_tanggal']) ? tanggal_indo($siswa['diterima_tanggal']) : '-'; ?></td>
            </tr>

            <!-- ORANG TUA -->
            <tr style="background-color: #fafafa;">
                <td>12.</td>
                <td colspan="3" style="font-weight: bold;">Nama Orang Tua</td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">a. Ayah</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['nama_ayah']); ?></td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">b. Ibu</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['nama_ibu']); ?></td>
            </tr>
            <tr>
                <td>13.</td>
                <td class="label-text">Alamat Orang Tua</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['alamat']); ?></td>
            </tr>
            <tr>
                <td>14.</td>
                <td class="label-text">Pekerjaan Orang Tua</td>
                <td>:</td>
                <td></td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">a. Ayah</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['pekerjaan_ayah']); ?></td>
            </tr>
            <tr>
                <td></td>
                <td class="label-text" style="padding-left: 20px;">b. Ibu</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['pekerjaan_ibu']); ?></td>
            </tr>

            <!-- WALI -->
            <tr style="background-color: #fafafa;">
                <td>15.</td>
                <td class="label-text">Nama Wali Siswa</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['nama_wali']); ?></td>
            </tr>
            <tr>
                <td>16.</td>
                <td class="label-text">Alamat Wali</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['alamat_wali']); ?></td>
            </tr>
            <tr>
                <td>17.</td>
                <td class="label-text">Pekerjaan Wali</td>
                <td>:</td>
                <td class="value-text"><?php echo htmlspecialchars($siswa['pekerjaan_wali']); ?></td>
            </tr>
        </table>

        <!-- FOTO & TANDA TANGAN -->
        <table class="signature-table">
            <tr>
                <!-- Spacer Kiri -->
                <td style="width: 35%;"></td>
                
                <!-- Foto (Bawah) -->
                <td style="width: 20%; vertical-align: bottom; text-align: center; padding-right: 15px; padding-bottom: 5px;">
                    <div style="width: 3cm; height: 4cm; border: 1px solid #333; display: inline-block; background-color: #fff; padding: 2px;">
                        <?php echo $foto_html; ?>
                    </div>
                </td>
                
                <!-- Tanda Tangan -->
                <td style="width: 45%; vertical-align: top; text-align: left; padding-left: 5px;">
                    <div style="font-size: 11pt;">
                        <?php echo htmlspecialchars($sekolah['kabupaten_kota'] ?? ''); ?>, <?php echo tanggal_indo(date('Y-m-d')); ?><br>
                        Kepala Sekolah,<br>
                        <br><br><br><br><br>
                        <strong><u><?php echo htmlspecialchars($sekolah['nama_kepsek']); ?></u></strong><br>
                        NIP. <?php echo htmlspecialchars($sekolah['nip_kepsek']); ?>
                    </div>
                </td>
            </tr>
        </table>

    </div>

</body>
</html>
<?php
$html = ob_get_clean();

$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);

// [LOGIKA UKURAN KERTAS]
switch ($ukuran_kertas) {
    case 'F4':
        $width_pt = 215 * 2.83465;
        $height_pt = 330 * 2.83465;
        $dompdf->setPaper([0, 0, $width_pt, $height_pt], 'portrait');
        break;
    default:
        $dompdf->setPaper('A4', 'portrait');
        break;
}

$dompdf->render();
$dompdf->stream("Identitas - " . htmlspecialchars($siswa['nama_lengkap']) . ".pdf", ["Attachment" => 0]);
?>